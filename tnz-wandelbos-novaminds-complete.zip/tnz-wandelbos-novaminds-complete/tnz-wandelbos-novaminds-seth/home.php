<?php

declare(strict_types=1);

header('Location: history.php', true, 302);
exit;