/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './index.php',
    './home.php',
    './history.php',
    './locaties.php',
    './locatie.php',
    './locations.php',
    './admin.php',
    './admin_locations.php',
    './admin_qrcodes.php',
    './templates/**/*.php'
  ],
  theme: {
    extend: {}
  },
  plugins: []
};
