<?php

declare(strict_types=1);

session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'httponly' => true,
    'samesite' => 'Lax',
]);

session_start();

require_once __DIR__ . '/db.php';

function h(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}

function csrfToken(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }

    return (string) $_SESSION['csrf_token'];
}

function validateCsrf(?string $token): bool
{
    $sessionToken = $_SESSION['csrf_token'] ?? '';

    return is_string($sessionToken)
        && $sessionToken !== ''
        && is_string($token)
        && hash_equals($sessionToken, $token);
}

function flash(string $type, string $message): void
{
    $_SESSION['admin_flash'] = [
        'type' => $type,
        'message' => $message,
    ];
}

function getFlash(): ?array
{
    if (!isset($_SESSION['admin_flash']) || !is_array($_SESSION['admin_flash'])) {
        return null;
    }

    $flash = $_SESSION['admin_flash'];
    unset($_SESSION['admin_flash']);

    return $flash;
}

function requireAdmin(): void
{
    if (empty($_SESSION['is_admin'])) {
        header('Location: admin.php');
        exit;
    }
}

requireAdmin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = (string) ($_POST['action'] ?? '');
    $token = $_POST['csrf_token'] ?? null;

    if (!validateCsrf(is_string($token) ? $token : null)) {
        flash('error', 'Ongeldige sessie. Vernieuw de pagina en probeer opnieuw.');
        header('Location: admin_locations.php');
        exit;
    }

    try {
        if ($action === 'save_location') {
            $id = (int) ($_POST['id'] ?? 0);
            $name = trim((string) ($_POST['name'] ?? ''));
            $slug = trim((string) ($_POST['slug'] ?? ''));

            if ($name === '' || $slug === '') {
                throw new RuntimeException('Naam en slug zijn verplicht.');
            }

            if (!preg_match('/^[a-z0-9\-]+$/', $slug)) {
                throw new RuntimeException('Slug mag alleen kleine letters, cijfers en streepjes bevatten.');
            }

            saveLocation([
                'name' => $name,
                'slug' => $slug,
                'short_text' => trim((string) ($_POST['short_text'] ?? '')),
                'long_text' => trim((string) ($_POST['long_text'] ?? '')),
                'latitude' => $_POST['latitude'] !== '' ? (float) $_POST['latitude'] : null,
                'longitude' => $_POST['longitude'] !== '' ? (float) $_POST['longitude'] : null,
                'sort_order' => (int) ($_POST['sort_order'] ?? 0),
                'is_active' => isset($_POST['is_active']),
                'panorama_url' => trim((string) ($_POST['panorama_url'] ?? '')),
            ], $id);

            flash('success', $id > 0 ? 'Locatie bijgewerkt.' : 'Locatie toegevoegd.');
        }

        if ($action === 'upload_image') {
            $locationId = (int) ($_POST['location_id'] ?? 0);
            $caption = trim((string) ($_POST['caption'] ?? ''));
            $yearLabel = trim((string) ($_POST['year_label'] ?? ''));
            $source = trim((string) ($_POST['source'] ?? ''));

            if ($locationId <= 0 || !isset($_FILES['image'])) {
                throw new RuntimeException('Kies een locatie en afbeelding.');
            }

            $uploadDir = __DIR__ . '/uploads';

            if (!is_dir($uploadDir) && !mkdir($uploadDir, 0775, true) && !is_dir($uploadDir)) {
                throw new RuntimeException('Uploadmap kon niet worden aangemaakt.');
            }

            $tmpName = (string) ($_FILES['image']['tmp_name'] ?? '');
            $size = (int) ($_FILES['image']['size'] ?? 0);
            $originalName = (string) ($_FILES['image']['name'] ?? '');
            $extension = strtolower((string) pathinfo($originalName, PATHINFO_EXTENSION));
            $mime = $tmpName !== '' ? (string) (mime_content_type($tmpName) ?: '') : '';

            $allowedExtensions = ['jpg', 'jpeg', 'png', 'webp'];
            $allowedMimes = ['image/jpeg', 'image/png', 'image/webp'];

            if (!is_uploaded_file($tmpName)) {
                throw new RuntimeException('Ongeldige uploadaanvraag.');
            }

            if ($size <= 0 || $size > 5 * 1024 * 1024) {
                throw new RuntimeException('Bestand te groot of ongeldig (max 5MB).');
            }

            if (!in_array($extension, $allowedExtensions, true) || !in_array($mime, $allowedMimes, true)) {
                throw new RuntimeException('Alleen JPG, PNG en WEBP zijn toegestaan.');
            }

            if (@getimagesize($tmpName) === false) {
                throw new RuntimeException('Bestand is geen geldige afbeelding.');
            }

            $filename = uniqid('loc_', true) . '.' . $extension;
            $target = $uploadDir . '/' . $filename;

            if (!move_uploaded_file($tmpName, $target)) {
                throw new RuntimeException('Upload mislukt.');
            }

            insertLocationImage($locationId, 'uploads/' . $filename, $caption, $yearLabel, $source);
            flash('success', 'Afbeelding succesvol geüpload.');
        }

        if ($action === 'add_quiz') {
            $locationId = (int) ($_POST['location_id'] ?? 0);
            $question = trim((string) ($_POST['question'] ?? ''));
            $optionA = trim((string) ($_POST['option_a'] ?? ''));
            $optionB = trim((string) ($_POST['option_b'] ?? ''));
            $optionC = trim((string) ($_POST['option_c'] ?? ''));
            $correct = trim((string) ($_POST['correct_option'] ?? 'a'));

            if ($locationId <= 0 || $question === '' || $optionA === '' || $optionB === '' || $optionC === '') {
                throw new RuntimeException('Vul alle quizvelden in.');
            }

            if (!in_array($correct, ['a', 'b', 'c'], true)) {
                $correct = 'a';
            }

            $pdo = getPdo();
            $stmt = $pdo->prepare(
                'INSERT INTO location_quizzes (location_id, question, option_a, option_b, option_c, correct_option, sort_order)
                 VALUES (:location_id, :question, :option_a, :option_b, :option_c, :correct_option, :sort_order)'
            );
            $stmt->execute([
                ':location_id' => $locationId,
                ':question' => $question,
                ':option_a' => $optionA,
                ':option_b' => $optionB,
                ':option_c' => $optionC,
                ':correct_option' => $correct,
                ':sort_order' => 0,
            ]);

            flash('success', 'Quizvraag toegevoegd.');
        }
    } catch (Throwable $exception) {
        flash('error', $exception->getMessage());
    }

    header('Location: admin_locations.php');
    exit;
}

$locations = fetchLocations(false);
$editId = (int) ($_GET['edit'] ?? 0);
$editLocation = $editId > 0 ? fetchLocationById($editId) : null;
$flash = getFlash();
$csrf = csrfToken();
?>
<!doctype html>
<html lang="nl">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Locatiebeheer | TNZ Wandelbos</title>
    <link rel="stylesheet" href="assets/css/tailwind.css">
    <link rel="stylesheet" href="assets/css/site.css">
</head>
<body class="seth-theme min-h-screen flex flex-col">
<header class="company-header border-b border-slate-300 px-4 py-3 sm:px-6">
    <div class="max-w-6xl mx-auto flex flex-wrap items-center justify-between gap-3">
        <div>
            <p class="text-sm font-semibold tracking-wide uppercase">TNZ Wandelbos Admin</p>
            <p class="text-[11px] uppercase tracking-wider opacity-85">Locatiebeheer, media en quizvragen</p>
        </div>
        <nav class="flex flex-wrap items-center gap-2 text-[11px] uppercase tracking-wider">
            <a href="history.php" class="company-link">Project</a>
            <a href="locaties.php" class="company-link">Publieke locaties</a>
            <a href="admin.php" class="company-link">Content</a>
            <a href="admin_qrcodes.php" class="company-link">QR-codes</a>
            <a href="admin.php?logout=1" class="company-link">Uitloggen</a>
        </nav>
    </div>
</header>

<main class="flex-1 px-4 py-6 sm:px-6">
    <div class="max-w-6xl mx-auto space-y-6">
        <?php if ($flash): ?>
            <div class="rounded-lg border border-slate-300 bg-slate-100 px-4 py-3 text-sm">
                <strong><?= h((string) $flash['type']) ?>:</strong> <?= h((string) $flash['message']) ?>
            </div>
        <?php endif; ?>

        <section class="rounded-xl border border-slate-300 bg-slate-100 p-5 sm:p-6">
            <h1 class="text-lg font-semibold"><?= $editLocation ? 'Locatie bewerken' : 'Nieuwe locatie toevoegen' ?></h1>
            <p class="mt-2 text-sm text-slate-700">Beheer routepunten, kaartcoördinaten en locatie-teksten vanuit één dashboard.</p>

            <form method="post" class="mt-4 grid grid-cols-1 gap-4 md:grid-cols-2">
                <input type="hidden" name="action" value="save_location">
                <input type="hidden" name="csrf_token" value="<?= h($csrf) ?>">
                <input type="hidden" name="id" value="<?= (int) ($editLocation['id'] ?? 0) ?>">

                <div>
                    <label class="block text-xs uppercase tracking-wider mb-1" for="name">Naam</label>
                    <input id="name" type="text" name="name" required class="w-full rounded-md border border-slate-300 bg-slate-50 px-3 py-2 text-sm" value="<?= h((string) ($editLocation['name'] ?? '')) ?>">
                </div>
                <div>
                    <label class="block text-xs uppercase tracking-wider mb-1" for="slug">Slug</label>
                    <input id="slug" type="text" name="slug" required pattern="[a-z0-9\-]+" class="w-full rounded-md border border-slate-300 bg-slate-50 px-3 py-2 text-sm" value="<?= h((string) ($editLocation['slug'] ?? '')) ?>">
                </div>
                <div class="md:col-span-2">
                    <label class="block text-xs uppercase tracking-wider mb-1" for="short_text">Korte tekst</label>
                    <textarea id="short_text" name="short_text" rows="2" class="w-full rounded-md border border-slate-300 bg-slate-50 px-3 py-2 text-sm"><?= h((string) ($editLocation['short_text'] ?? '')) ?></textarea>
                </div>
                <div class="md:col-span-2">
                    <label class="block text-xs uppercase tracking-wider mb-1" for="long_text">Lange tekst</label>
                    <textarea id="long_text" name="long_text" rows="5" class="w-full rounded-md border border-slate-300 bg-slate-50 px-3 py-2 text-sm"><?= h((string) ($editLocation['long_text'] ?? '')) ?></textarea>
                </div>
                <div>
                    <label class="block text-xs uppercase tracking-wider mb-1" for="latitude">Latitude</label>
                    <input id="latitude" type="number" step="0.0000001" name="latitude" class="w-full rounded-md border border-slate-300 bg-slate-50 px-3 py-2 text-sm" value="<?= h((string) ($editLocation['latitude'] ?? '')) ?>">
                </div>
                <div>
                    <label class="block text-xs uppercase tracking-wider mb-1" for="longitude">Longitude</label>
                    <input id="longitude" type="number" step="0.0000001" name="longitude" class="w-full rounded-md border border-slate-300 bg-slate-50 px-3 py-2 text-sm" value="<?= h((string) ($editLocation['longitude'] ?? '')) ?>">
                </div>
                <div>
                    <label class="block text-xs uppercase tracking-wider mb-1" for="sort_order">Volgorde</label>
                    <input id="sort_order" type="number" name="sort_order" class="w-full rounded-md border border-slate-300 bg-slate-50 px-3 py-2 text-sm" value="<?= h((string) ($editLocation['sort_order'] ?? '0')) ?>">
                </div>
                <div>
                    <label class="block text-xs uppercase tracking-wider mb-1" for="panorama_url">Panorama URL</label>
                    <input id="panorama_url" type="url" name="panorama_url" class="w-full rounded-md border border-slate-300 bg-slate-50 px-3 py-2 text-sm" value="<?= h((string) ($editLocation['panorama_url'] ?? '')) ?>">
                </div>
                <div class="md:col-span-2 flex flex-wrap items-center gap-4">
                    <label class="inline-flex items-center gap-2 text-sm">
                        <input type="checkbox" name="is_active" value="1" <?= !isset($editLocation['is_active']) || (int) $editLocation['is_active'] === 1 ? 'checked' : '' ?>>
                        <span>Actieve locatie</span>
                    </label>
                    <div class="flex gap-2">
                        <button type="submit" class="inline-flex items-center rounded-full border border-slate-300 px-4 py-2 text-xs font-semibold uppercase tracking-wider">Opslaan</button>
                        <a href="admin_locations.php" class="inline-flex items-center rounded-full border border-slate-300 px-4 py-2 text-xs font-semibold uppercase tracking-wider">Nieuwe invoer</a>
                    </div>
                </div>
            </form>
        </section>

        <section class="grid grid-cols-1 gap-6 lg:grid-cols-2">
            <article class="rounded-xl border border-slate-300 bg-slate-100 p-5 sm:p-6">
                <h2 class="text-sm font-semibold uppercase tracking-wide">Afbeelding uploaden</h2>
                <form method="post" enctype="multipart/form-data" class="mt-4 space-y-3">
                    <input type="hidden" name="action" value="upload_image">
                    <input type="hidden" name="csrf_token" value="<?= h($csrf) ?>">

                    <label class="block text-xs uppercase tracking-wider mb-1" for="location_id">Locatie</label>
                    <select id="location_id" name="location_id" required class="w-full rounded-md border border-slate-300 bg-slate-50 px-3 py-2 text-sm">
                        <option value="">Kies locatie</option>
                        <?php foreach ($locations as $location): ?>
                            <option value="<?= (int) $location['id'] ?>"><?= h((string) $location['name']) ?></option>
                        <?php endforeach; ?>
                    </select>

                    <label class="block text-xs uppercase tracking-wider mb-1" for="image">Afbeelding</label>
                    <input id="image" type="file" name="image" accept="image/jpeg,image/png,image/webp" required class="w-full text-sm">

                    <label class="block text-xs uppercase tracking-wider mb-1" for="caption">Bijschrift</label>
                    <input id="caption" type="text" name="caption" class="w-full rounded-md border border-slate-300 bg-slate-50 px-3 py-2 text-sm">

                    <div class="grid grid-cols-2 gap-3">
                        <div>
                            <label class="block text-xs uppercase tracking-wider mb-1" for="year_label">Periode / jaar</label>
                            <input id="year_label" type="text" name="year_label" class="w-full rounded-md border border-slate-300 bg-slate-50 px-3 py-2 text-sm">
                        </div>
                        <div>
                            <label class="block text-xs uppercase tracking-wider mb-1" for="source">Bron</label>
                            <input id="source" type="text" name="source" class="w-full rounded-md border border-slate-300 bg-slate-50 px-3 py-2 text-sm">
                        </div>
                    </div>

                    <button type="submit" class="inline-flex items-center rounded-full border border-slate-300 px-4 py-2 text-xs font-semibold uppercase tracking-wider">Uploaden</button>
                </form>
            </article>

            <article class="rounded-xl border border-slate-300 bg-slate-100 p-5 sm:p-6">
                <h2 class="text-sm font-semibold uppercase tracking-wide">Quizvraag toevoegen</h2>
                <form method="post" class="mt-4 space-y-3">
                    <input type="hidden" name="action" value="add_quiz">
                    <input type="hidden" name="csrf_token" value="<?= h($csrf) ?>">

                    <label class="block text-xs uppercase tracking-wider mb-1" for="quiz_location_id">Locatie</label>
                    <select id="quiz_location_id" name="location_id" required class="w-full rounded-md border border-slate-300 bg-slate-50 px-3 py-2 text-sm">
                        <option value="">Kies locatie</option>
                        <?php foreach ($locations as $location): ?>
                            <option value="<?= (int) $location['id'] ?>"><?= h((string) $location['name']) ?></option>
                        <?php endforeach; ?>
                    </select>

                    <label class="block text-xs uppercase tracking-wider mb-1" for="question">Vraag</label>
                    <textarea id="question" name="question" rows="3" required class="w-full rounded-md border border-slate-300 bg-slate-50 px-3 py-2 text-sm"></textarea>

                    <div class="grid grid-cols-1 gap-3 sm:grid-cols-3">
                        <div>
                            <label class="block text-xs uppercase tracking-wider mb-1" for="option_a">Optie A</label>
                            <input id="option_a" type="text" name="option_a" required class="w-full rounded-md border border-slate-300 bg-slate-50 px-3 py-2 text-sm">
                        </div>
                        <div>
                            <label class="block text-xs uppercase tracking-wider mb-1" for="option_b">Optie B</label>
                            <input id="option_b" type="text" name="option_b" required class="w-full rounded-md border border-slate-300 bg-slate-50 px-3 py-2 text-sm">
                        </div>
                        <div>
                            <label class="block text-xs uppercase tracking-wider mb-1" for="option_c">Optie C</label>
                            <input id="option_c" type="text" name="option_c" required class="w-full rounded-md border border-slate-300 bg-slate-50 px-3 py-2 text-sm">
                        </div>
                    </div>

                    <label class="block text-xs uppercase tracking-wider mb-1" for="correct_option">Correct antwoord</label>
                    <select id="correct_option" name="correct_option" class="w-full rounded-md border border-slate-300 bg-slate-50 px-3 py-2 text-sm">
                        <option value="a">Optie A</option>
                        <option value="b">Optie B</option>
                        <option value="c">Optie C</option>
                    </select>

                    <button type="submit" class="inline-flex items-center rounded-full border border-slate-300 px-4 py-2 text-xs font-semibold uppercase tracking-wider">Quiz opslaan</button>
                </form>
            </article>
        </section>

        <section>
            <h2 class="text-sm font-semibold uppercase tracking-wide mb-3">Alle locaties</h2>
            <div class="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3">
                <?php foreach ($locations as $location): ?>
                    <?php
                    $images = fetchLocationImages((int) $location['id']);
                    $imageUrl = (string) ($images[0]['image_url'] ?? 'https://picsum.photos/seed/' . rawurlencode((string) $location['slug']) . '/1200/700');
                    ?>
                    <article class="rounded-xl border border-slate-300 bg-slate-100 overflow-hidden">
                        <img src="<?= h($imageUrl) ?>" alt="<?= h((string) $location['name']) ?>" class="h-36 w-full object-cover" loading="lazy">
                        <div class="p-4">
                            <div class="flex items-center justify-between gap-2">
                                <h3 class="text-sm font-semibold uppercase tracking-wide"><?= h((string) $location['name']) ?></h3>
                                <span class="text-[10px] uppercase tracking-wider border border-slate-300 rounded-full px-2 py-0.5"><?= (int) $location['is_active'] === 1 ? 'Actief' : 'Inactief' ?></span>
                            </div>
                            <p class="mt-2 text-xs text-slate-700 min-h-10"><?= h((string) ($location['short_text'] ?? '')) ?></p>
                            <p class="mt-2 text-[11px] break-all">locatie.php?slug=<?= h((string) $location['slug']) ?></p>
                            <div class="mt-3 flex flex-wrap gap-2">
                                <a href="admin_locations.php?edit=<?= (int) $location['id'] ?>" class="inline-flex items-center rounded-full border border-slate-300 px-3 py-1 text-[11px] uppercase tracking-wider">Bewerk</a>
                                <a href="locatie.php?slug=<?= rawurlencode((string) $location['slug']) ?>" class="inline-flex items-center rounded-full border border-slate-300 px-3 py-1 text-[11px] uppercase tracking-wider" target="_blank" rel="noopener">Open</a>
                            </div>
                        </div>
                    </article>
                <?php endforeach; ?>
            </div>
        </section>
    </div>
</main>

<footer class="company-footer border-t border-slate-300 px-4 py-3 sm:px-6">
    <div class="max-w-6xl mx-auto text-[11px] uppercase tracking-wider opacity-90">TNZ Wandelbos · locatiebeheer</div>
</footer>
</body>
</html>
