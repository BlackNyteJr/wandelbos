<?php

declare(strict_types=1);

require_once __DIR__ . '/db.php';

function h(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}

$slug = trim((string) ($_GET['slug'] ?? ''));
$location = $slug !== '' ? fetchLocationBySlug($slug) : null;
$images = $location ? fetchLocationImages((int) $location['id']) : [];
$quizzes = $location ? fetchLocationQuizzes((int) $location['id']) : [];

if ($location === null) {
    http_response_code(404);
}
?>
<!doctype html>
<html lang="nl">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= $location ? h((string) $location['name']) : 'Locatie niet gevonden' ?> | TNZ Wandelbos</title>
    <link rel="stylesheet" href="assets/css/tailwind.css">
    <link rel="stylesheet" href="assets/css/site.css">
</head>
<body class="seth-theme min-h-screen flex flex-col">
<header class="company-header border-b border-slate-300 px-4 py-3 sm:px-6">
    <div class="max-w-6xl mx-auto flex flex-wrap items-center justify-between gap-3">
        <div>
            <p class="text-sm font-semibold tracking-wide uppercase">TNZ Wandelbos</p>
            <p class="text-[11px] uppercase tracking-wider opacity-85">Locatiebeleving met foto, quiz en spel</p>
        </div>
        <nav class="flex flex-wrap items-center gap-2 text-[11px] uppercase tracking-wider">
            <a href="home.php" class="company-link">Start</a>
            <a href="locaties.php" class="company-link">Locaties</a>
            <a href="history.php" class="company-link">Project</a>
        </nav>
    </div>
</header>

<main class="flex-1 px-4 py-6 sm:px-6">
    <div class="max-w-6xl mx-auto space-y-6">
        <?php if ($location === null): ?>
            <section class="rounded-xl border border-slate-300 bg-slate-100 p-5">
                <h1 class="text-lg font-semibold">Locatie niet gevonden</h1>
                <p class="mt-2 text-sm text-slate-700">Deze link is niet (meer) geldig. Kies een locatie vanuit het overzicht.</p>
                <a href="locaties.php" class="mt-3 inline-flex items-center text-xs font-semibold hover:underline">← Terug naar locaties</a>
            </section>
        <?php else: ?>
            <?php $heroImage = (string) ($images[0]['image_url'] ?? 'https://picsum.photos/seed/' . rawurlencode((string) $location['slug']) . '/1600/900'); ?>
            <section class="rounded-xl border border-slate-300 bg-slate-100 overflow-hidden">
                <img src="<?= h($heroImage) ?>" alt="<?= h((string) $location['name']) ?>" class="h-56 sm:h-72 w-full object-cover" loading="lazy">
                <div class="p-5 sm:p-6">
                    <a href="locaties.php" class="inline-flex items-center text-xs hover:underline">← Terug naar locaties</a>
                    <h1 class="mt-2 text-xl sm:text-2xl font-semibold"><?= h((string) $location['name']) ?></h1>
                    <p class="mt-2 text-sm text-slate-700"><?= h((string) ($location['short_text'] ?? '')) ?></p>
                    <p class="mt-3 text-sm leading-6 text-slate-700"><?= nl2br(h((string) ($location['long_text'] ?? ''))) ?></p>
                </div>
            </section>

            <section class="rounded-xl border border-slate-300 bg-slate-100 p-5 sm:p-6">
                <h2 class="text-sm font-semibold uppercase tracking-wide">Historisch beeldmateriaal</h2>
                <?php if ($images === []): ?>
                    <p class="mt-2 text-sm text-slate-700">Voor deze locatie is nog geen beeldmateriaal toegevoegd.</p>
                <?php else: ?>
                    <div class="mt-4 grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3">
                        <?php foreach ($images as $image): ?>
                            <figure class="rounded-lg border border-slate-300 bg-slate-50 overflow-hidden">
                                <a href="<?= h((string) $image['image_url']) ?>" target="_blank" rel="noopener noreferrer">
                                    <img src="<?= h((string) $image['image_url']) ?>" alt="<?= h((string) ($image['caption'] ?: 'Historische afbeelding')) ?>" class="h-40 w-full object-cover" loading="lazy">
                                </a>
                                <figcaption class="p-3 text-xs text-slate-700 space-y-1">
                                    <p class="font-semibold"><?= h((string) ($image['caption'] ?: 'Zonder bijschrift')) ?></p>
                                    <?php if (!empty($image['year_label'])): ?><p>Periode: <?= h((string) $image['year_label']) ?></p><?php endif; ?>
                                    <?php if (!empty($image['source'])): ?><p>Bron: <?= h((string) $image['source']) ?></p><?php endif; ?>
                                </figcaption>
                            </figure>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </section>

            <?php if ((string) ($location['panorama_url'] ?? '') !== ''): ?>
                <section class="rounded-xl border border-slate-300 bg-slate-100 p-5 sm:p-6">
                    <h2 class="text-sm font-semibold uppercase tracking-wide">360° panorama</h2>
                    <iframe class="mt-4 w-full h-72 rounded-lg border border-slate-300" src="<?= h((string) $location['panorama_url']) ?>" title="Panorama"></iframe>
                </section>
            <?php endif; ?>

            <?php if ($quizzes !== []): ?>
                <section class="rounded-xl border border-slate-300 bg-slate-100 p-5 sm:p-6">
                    <h2 class="text-sm font-semibold uppercase tracking-wide">Kennistoets</h2>
                    <p class="mt-2 text-sm text-slate-700">Test je kennis over deze historische locatie.</p>
                    <form id="quiz-form" class="mt-4 space-y-4">
                        <?php foreach ($quizzes as $index => $quiz): ?>
                            <fieldset class="rounded-lg border border-slate-300 p-4" data-correct="<?= h((string) $quiz['correct_option']) ?>">
                                <legend class="font-semibold text-sm mb-2"><?= ($index + 1) . '. ' . h((string) $quiz['question']) ?></legend>
                                <label class="flex items-start gap-2 text-sm mb-2"><input type="radio" name="q<?= (int) $quiz['id'] ?>" value="a"> <span><?= h((string) $quiz['option_a']) ?></span></label>
                                <label class="flex items-start gap-2 text-sm mb-2"><input type="radio" name="q<?= (int) $quiz['id'] ?>" value="b"> <span><?= h((string) $quiz['option_b']) ?></span></label>
                                <label class="flex items-start gap-2 text-sm"><input type="radio" name="q<?= (int) $quiz['id'] ?>" value="c"> <span><?= h((string) $quiz['option_c']) ?></span></label>
                            </fieldset>
                        <?php endforeach; ?>
                        <div class="flex flex-wrap items-center gap-3">
                            <button type="button" id="check-quiz" class="inline-flex items-center rounded-full border border-slate-300 px-4 py-2 text-xs font-semibold uppercase tracking-wider">Controleer antwoorden</button>
                            <p id="quiz-result" class="text-sm font-semibold" aria-live="polite"></p>
                        </div>
                    </form>
                </section>
            <?php endif; ?>

            <section class="rounded-xl border border-slate-300 bg-slate-100 p-5 sm:p-6">
                <h2 class="text-sm font-semibold uppercase tracking-wide">Interactief memory-spel</h2>
                <p class="mt-2 text-sm text-slate-700">Kies een niveau en vind alle paren.</p>
                <div class="mt-4 flex flex-wrap items-center gap-3 text-sm">
                    <label for="level">Niveau:</label>
                    <select id="level" class="rounded-full border border-slate-300 bg-slate-50 px-3 py-1 text-xs">
                        <option value="easy">Kind (4 paren)</option>
                        <option value="medium" selected>Jongere (6 paren)</option>
                        <option value="hard">Volwassene (8 paren)</option>
                    </select>
                    <button type="button" id="start-game" class="inline-flex items-center rounded-full border border-slate-300 px-4 py-2 text-xs font-semibold uppercase tracking-wider">Start spel</button>
                </div>
                <div id="memory-board" class="mt-4 grid grid-cols-4 sm:grid-cols-6 gap-2"></div>
                <p id="memory-status" class="mt-3 text-sm"></p>
            </section>
        <?php endif; ?>
    </div>
</main>

<footer class="company-footer border-t border-slate-300 px-4 py-3 sm:px-6">
    <div class="max-w-6xl mx-auto text-[11px] uppercase tracking-wider opacity-90">TNZ Wandelbos · locatiebeleving</div>
</footer>

<script>
(function () {
    const checkButton = document.getElementById('check-quiz');
    const quizResult = document.getElementById('quiz-result');

    if (checkButton && quizResult) {
        checkButton.addEventListener('click', function () {
            const blocks = Array.from(document.querySelectorAll('fieldset[data-correct]'));
            let score = 0;

            blocks.forEach((block) => {
                const selected = block.querySelector('input[type="radio"]:checked');
                if (selected && selected.value === block.dataset.correct) {
                    score += 1;
                }
            });

            quizResult.textContent = 'Je score: ' + score + ' van ' + blocks.length;
        });
    }

    const board = document.getElementById('memory-board');
    const levelSelect = document.getElementById('level');
    const startButton = document.getElementById('start-game');
    const status = document.getElementById('memory-status');

    if (!board || !levelSelect || !startButton || !status) {
        return;
    }

    const allIcons = ['🌳', '🏰', '📜', '⛵', '🕰️', '🧭', '🏞️', '🧱'];
    let firstCard = null;
    let locked = false;
    let matches = 0;
    let neededMatches = 0;

    function shuffle(array) {
        for (let index = array.length - 1; index > 0; index -= 1) {
            const randomIndex = Math.floor(Math.random() * (index + 1));
            [array[index], array[randomIndex]] = [array[randomIndex], array[index]];
        }
        return array;
    }

    function hide(card) {
        if (card.classList.contains('matched')) {
            return;
        }
        card.textContent = '?';
        card.classList.remove('bg-emerald-700/40');
    }

    function reveal(card) {
        card.textContent = card.dataset.value;
        card.classList.add('bg-emerald-700/40');
    }

    function createBoard() {
        const level = levelSelect.value;
        const pairCount = level === 'easy' ? 4 : level === 'hard' ? 8 : 6;
        const deck = shuffle([...allIcons.slice(0, pairCount), ...allIcons.slice(0, pairCount)]);

        firstCard = null;
        locked = false;
        matches = 0;
        neededMatches = pairCount;
        status.textContent = 'Zoek alle paren!';
        board.innerHTML = '';

        deck.forEach((icon) => {
            const card = document.createElement('button');
            card.type = 'button';
            card.dataset.value = icon;
            card.className = 'rounded-md border border-slate-300 bg-slate-50 h-14 text-lg font-semibold';
            card.textContent = '?';

            card.addEventListener('click', function () {
                if (locked || card.classList.contains('matched') || card === firstCard) {
                    return;
                }

                reveal(card);

                if (!firstCard) {
                    firstCard = card;
                    return;
                }

                if (firstCard.dataset.value === card.dataset.value) {
                    firstCard.classList.add('matched');
                    card.classList.add('matched');
                    firstCard = null;
                    matches += 1;

                    if (matches === neededMatches) {
                        status.textContent = 'Klaar! Je hebt alle paren gevonden.';
                    }

                    return;
                }

                const previous = firstCard;
                firstCard = null;
                locked = true;

                setTimeout(function () {
                    hide(previous);
                    hide(card);
                    locked = false;
                }, 650);
            });

            board.appendChild(card);
        });
    }

    startButton.addEventListener('click', createBoard);
    createBoard();
})();
</script>
</body>
</html>
