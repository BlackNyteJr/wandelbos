<?php

declare(strict_types=1);

function env(string $key, ?string $default = null): ?string
{
    $value = getenv($key);

    if ($value === false || $value === '') {
        return $default;
    }

    return $value;
}

function appUrl(string $path = ''): string
{
    $baseUrl = rtrim((string) env('APP_URL', ''), '/');

    if ($baseUrl === '') {
        return ltrim($path, '/');
    }

    return $baseUrl . '/' . ltrim($path, '/');
}
