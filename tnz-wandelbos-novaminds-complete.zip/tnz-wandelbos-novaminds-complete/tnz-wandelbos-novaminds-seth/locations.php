<?php

declare(strict_types=1);

header('Location: locaties.php', true, 302);
exit;
