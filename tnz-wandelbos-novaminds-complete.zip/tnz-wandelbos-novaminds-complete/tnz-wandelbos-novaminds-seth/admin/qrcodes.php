<?php

declare(strict_types=1);

header('Location: ../admin_qrcodes.php', true, 302);
exit;
