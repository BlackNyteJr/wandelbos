<?php

declare(strict_types=1);

header('Location: ../admin.php?logout=1', true, 302);
exit;
