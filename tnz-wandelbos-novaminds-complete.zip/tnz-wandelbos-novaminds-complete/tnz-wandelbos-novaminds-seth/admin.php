<?php

declare(strict_types=1);

session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'httponly' => true,
    'samesite' => 'Lax',
]);

session_start();

require_once __DIR__ . '/db.php';

function h(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}

function getCsrfToken(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }

    return (string) $_SESSION['csrf_token'];
}

function validateCsrfToken(?string $token): bool
{
    $sessionToken = $_SESSION['csrf_token'] ?? '';

    if (!is_string($sessionToken) || $sessionToken === '' || $token === null) {
        return false;
    }

    return hash_equals($sessionToken, $token);
}

function adminPasswordIsValid(string $providedPassword): bool
{
    $configuredHash = (string) env('ADMIN_PASSWORD_HASH', '');

    if ($configuredHash !== '') {
        return password_verify($providedPassword, $configuredHash);
    }

    $configuredPassword = (string) env('ADMIN_PASSWORD', 'change-me-now');
    return hash_equals($configuredPassword, $providedPassword);
}

$adminUser = (string) env('ADMIN_USERNAME', 'admin');

if (isset($_GET['logout'])) {
    session_destroy();
    header('Location: admin.php');
    exit;
}

$loginError = null;
$saveSuccess = false;
$saveError = null;

if (isset($_POST['action']) && $_POST['action'] === 'login') {
    $username = trim((string) ($_POST['username'] ?? ''));
    $password = (string) ($_POST['password'] ?? '');
    $csrfToken = $_POST['csrf_token'] ?? null;

    if (!validateCsrfToken(is_string($csrfToken) ? $csrfToken : null)) {
        $loginError = 'Ongeldige sessie. Vernieuw de pagina en probeer opnieuw.';
    } elseif ($username === $adminUser && adminPasswordIsValid($password)) {
        session_regenerate_id(true);
        $_SESSION['is_admin'] = true;
        header('Location: admin.php');
        exit;
    } else {
        $loginError = 'Onjuiste gebruikersnaam of wachtwoord.';
    }
}

$isAdmin = !empty($_SESSION['is_admin']);

$contentConfig = [
    'hero' => [
        'label' => 'Hero sectie',
        'fields' => [
            'home_hero_title' => ['label' => 'Hero titel', 'title' => true, 'body' => false, 'textarea' => false],
            'home_hero_subtitle' => ['label' => 'Hero ondertitel / intro', 'title' => false, 'body' => true, 'textarea' => true],
            'home_hero_cta_game' => ['label' => 'Tekst knop "Speel het Spel"', 'title' => false, 'body' => true, 'textarea' => false],
            'home_hero_cta_quiz' => ['label' => 'Tekst knop "Doe de Quiz"', 'title' => false, 'body' => true, 'textarea' => false],
        ],
    ],
    'origin' => [
        'label' => 'Hoe is dit project ontstaan?',
        'fields' => [
            'home_origin_title' => ['label' => 'Sectietitel', 'title' => true, 'body' => false, 'textarea' => false],
            'home_origin_body' => ['label' => 'Tekst (HTML toegestaan)', 'title' => false, 'body' => true, 'textarea' => true],
        ],
    ],
    'why' => [
        'label' => 'Waarom dit project?',
        'fields' => [
            'home_why_title' => ['label' => 'Sectietitel', 'title' => true, 'body' => false, 'textarea' => false],
            'home_why_educatief_title' => ['label' => 'Kaart 1 titel (Educatief)', 'title' => true, 'body' => false, 'textarea' => false],
            'home_why_educatief_body' => ['label' => 'Kaart 1 tekst', 'title' => false, 'body' => true, 'textarea' => true],
            'home_why_interactief_title' => ['label' => 'Kaart 2 titel (Interactief)', 'title' => true, 'body' => false, 'textarea' => false],
            'home_why_interactief_body' => ['label' => 'Kaart 2 tekst', 'title' => false, 'body' => true, 'textarea' => true],
            'home_why_alle_leeftijden_title' => ['label' => 'Kaart 3 titel (Voor alle leeftijden)', 'title' => true, 'body' => false, 'textarea' => false],
            'home_why_alle_leeftijden_body' => ['label' => 'Kaart 3 tekst', 'title' => false, 'body' => true, 'textarea' => true],
        ],
    ],
    'footer' => [
        'label' => 'Footer & contact',
        'fields' => [
            'home_footer_title' => ['label' => 'Footer titel', 'title' => true, 'body' => false, 'textarea' => false],
            'home_footer_body' => ['label' => 'Footer tekst', 'title' => false, 'body' => true, 'textarea' => true],
            'home_footer_contact' => ['label' => 'Contactlabel + e-mailadres', 'title' => true, 'body' => true, 'textarea' => false],
            'home_footer_address' => ['label' => 'Adreslabel + waarde', 'title' => true, 'body' => true, 'textarea' => false],
            'home_footer_phone' => ['label' => 'Telefoonlabel + nummer', 'title' => true, 'body' => true, 'textarea' => false],
            'home_footer_follow' => ['label' => 'Volg-ons-label + tekst', 'title' => true, 'body' => true, 'textarea' => false],
        ],
    ],
];

$allIds = [];

foreach ($contentConfig as $section) {
    foreach ($section['fields'] as $id => $_) {
        $allIds[] = $id;
    }
}

if ($isAdmin && isset($_POST['action']) && $_POST['action'] === 'save_content') {
    $csrfToken = $_POST['csrf_token'] ?? null;

    if (!validateCsrfToken(is_string($csrfToken) ? $csrfToken : null)) {
        $saveError = 'Ongeldige sessie. Vernieuw de pagina en probeer opnieuw.';
    } else {
        try {
            $pdo = getPdo();
            $pdo->beginTransaction();

            $stmt = $pdo->prepare(
                'INSERT INTO content_blocks (id, title, body)
                 VALUES (:id, :title, :body)
                 ON DUPLICATE KEY UPDATE title = VALUES(title), body = VALUES(body)'
            );

            foreach ($allIds as $id) {
                $titleKey = $id . '_title';
                $bodyKey = $id . '_body';

                $title = isset($_POST[$titleKey]) ? trim((string) $_POST[$titleKey]) : null;
                $body = isset($_POST[$bodyKey]) ? trim((string) $_POST[$bodyKey]) : null;

                $title = ($title === '') ? null : $title;
                $body = ($body === '') ? null : $body;

                $stmt->execute([
                    ':id' => $id,
                    ':title' => $title,
                    ':body' => $body,
                ]);
            }

            $pdo->commit();
            $saveSuccess = true;
        } catch (Throwable $exception) {
            if (isset($pdo) && $pdo instanceof PDO && $pdo->inTransaction()) {
                $pdo->rollBack();
            }

            $saveError = 'Er ging iets mis bij het opslaan. Controleer de databaseconfiguratie.';
        }
    }
}

$content = [];

try {
    $content = getContentBlocks();
} catch (Throwable $exception) {
    $content = [];
}

function fieldValue(array $content, string $id, string $key): string
{
    if (isset($content[$id][$key]) && $content[$id][$key] !== null) {
        return (string) $content[$id][$key];
    }

    return '';
}

$csrf = getCsrfToken();
?>
<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin | TNZ Wandelbos</title>
    <link rel="stylesheet" href="assets/css/tailwind.css">
    <link rel="stylesheet" href="assets/css/site.css">
</head>
<body class="seth-theme admin-page min-h-screen bg-slate-100 text-slate-900 flex items-center justify-center py-10">
<?php if (!$isAdmin): ?>
    <div class="w-full max-w-md mx-auto bg-white shadow-lg rounded-2xl border border-slate-200 p-8">
        <div class="flex items-center gap-3 mb-6">
            <div class="h-9 w-9 rounded-md bg-slate-900 flex items-center justify-center text-white text-sm font-semibold">WB</div>
            <div>
                <h1 class="text-lg font-semibold text-slate-900">Admin login</h1>
                <p class="text-xs text-slate-500 mt-0.5">Beheer pagina-content en projectteksten.</p>
            </div>
        </div>

        <?php if ($loginError): ?>
            <div class="mb-4 rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-xs text-red-700">
                <?php echo h($loginError); ?>
            </div>
        <?php endif; ?>

        <form method="post" class="space-y-4">
            <input type="hidden" name="action" value="login">
            <input type="hidden" name="csrf_token" value="<?php echo h($csrf); ?>">
            <div>
                <label for="username" class="block text-xs font-medium text-slate-700">Gebruikersnaam</label>
                <input type="text" id="username" name="username" class="mt-1 block w-full rounded-md border-slate-300 shadow-sm text-sm focus:border-slate-900 focus:ring-slate-900" required autocomplete="username">
            </div>
            <div>
                <label for="password" class="block text-xs font-medium text-slate-700">Wachtwoord</label>
                <input type="password" id="password" name="password" class="mt-1 block w-full rounded-md border-slate-300 shadow-sm text-sm focus:border-slate-900 focus:ring-slate-900" required autocomplete="current-password">
            </div>
            <button type="submit" class="w-full inline-flex items-center justify-center rounded-md bg-slate-900 px-4 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-slate-800 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-slate-900">
                Inloggen
            </button>
        </form>
    </div>
<?php else: ?>
    <div class="w-full max-w-5xl mx-auto bg-white shadow-xl rounded-2xl border border-slate-200">
        <div class="flex items-center justify-between border-b border-slate-200 px-6 py-4 bg-slate-50 rounded-t-2xl">
            <div>
                <h1 class="text-lg font-semibold text-slate-900">Content beheren</h1>
                <p class="text-xs text-slate-500 mt-0.5">Teksten voor de historische landingspagina beheren.</p>
            </div>
            <div class="flex items-center gap-3">
                <a href="admin_locations.php" class="text-xs font-medium text-slate-500 hover:text-slate-900">Locatiebeheer</a>
                <a href="admin_qrcodes.php" class="text-xs font-medium text-slate-500 hover:text-slate-900">QR-codes</a>
                <a href="?logout=1" class="text-xs font-medium text-slate-500 hover:text-slate-900">Uitloggen</a>
            </div>
        </div>

        <div class="px-6 pt-4 pb-6">
            <?php if ($saveSuccess): ?>
                <div class="mb-4 rounded-lg border border-emerald-200 bg-emerald-50 px-3 py-2 text-xs text-emerald-800">De wijzigingen zijn opgeslagen.</div>
            <?php elseif ($saveError): ?>
                <div class="mb-4 rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-xs text-red-700"><?php echo h($saveError); ?></div>
            <?php endif; ?>

            <form method="post" class="space-y-8">
                <input type="hidden" name="action" value="save_content">
                <input type="hidden" name="csrf_token" value="<?php echo h($csrf); ?>">

                <?php foreach ($contentConfig as $section): ?>
                    <section class="border border-slate-100 rounded-xl p-4 sm:p-5">
                        <h2 class="text-sm font-semibold text-slate-900"><?php echo h($section['label']); ?></h2>
                        <div class="mt-4 grid gap-4 sm:grid-cols-2">
                            <?php foreach ($section['fields'] as $id => $field): ?>
                                <div class="sm:col-span-<?php echo $field['textarea'] ? '2' : '1'; ?>">
                                    <label class="block text-xs font-medium text-slate-700 mb-1.5"><?php echo h($field['label']); ?></label>

                                    <?php if ($field['title'] && $field['body']): ?>
                                        <div class="grid gap-2">
                                            <input type="text" name="<?php echo h($id . '_title'); ?>" value="<?php echo h(fieldValue($content, $id, 'title')); ?>" class="block w-full rounded-md border-slate-300 shadow-sm text-xs focus:border-slate-900 focus:ring-slate-900" placeholder="Label">
                                            <input type="text" name="<?php echo h($id . '_body'); ?>" value="<?php echo h(fieldValue($content, $id, 'body')); ?>" class="block w-full rounded-md border-slate-300 shadow-sm text-xs focus:border-slate-900 focus:ring-slate-900" placeholder="Waarde">
                                        </div>
                                    <?php elseif ($field['title']): ?>
                                        <input type="text" name="<?php echo h($id . '_title'); ?>" value="<?php echo h(fieldValue($content, $id, 'title')); ?>" class="block w-full rounded-md border-slate-300 shadow-sm text-sm focus:border-slate-900 focus:ring-slate-900">
                                    <?php elseif ($field['body'] && $field['textarea']): ?>
                                        <textarea name="<?php echo h($id . '_body'); ?>" rows="5" class="block w-full rounded-md border-slate-300 shadow-sm text-sm focus:border-slate-900 focus:ring-slate-900"><?php echo h(fieldValue($content, $id, 'body')); ?></textarea>
                                    <?php elseif ($field['body']): ?>
                                        <input type="text" name="<?php echo h($id . '_body'); ?>" value="<?php echo h(fieldValue($content, $id, 'body')); ?>" class="block w-full rounded-md border-slate-300 shadow-sm text-sm focus:border-slate-900 focus:ring-slate-900">
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </section>
                <?php endforeach; ?>

                <div class="flex items-center justify-end gap-3 pt-2">
                    <a href="history.php" class="inline-flex items-center justify-center rounded-md border border-slate-300 bg-white px-4 py-2 text-xs font-medium text-slate-700 shadow-sm hover:bg-slate-50" target="_blank">Bekijk landingspagina</a>
                    <button type="submit" class="inline-flex items-center justify-center rounded-md bg-slate-900 px-5 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-slate-800 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-slate-900">
                        Wijzigingen opslaan
                    </button>
                </div>
            </form>
        </div>
    </div>
<?php endif; ?>
</body>
</html>
