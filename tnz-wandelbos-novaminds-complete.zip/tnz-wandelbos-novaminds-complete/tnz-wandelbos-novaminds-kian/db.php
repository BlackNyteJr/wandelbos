<?php
// Eenvoudige PDO-helper voor MySQL-verbinding

// PAS DEZE VARIABELEN AAN NAAR JE EIGEN DATABASE
$DB_HOST = '127.0.0.1';
$DB_NAME = 'geschiedenis_project';
$DB_USER = 'root';
$DB_PASS = '';
$DB_CHARSET = 'utf8mb4';

/**
 * Geeft een PDO-instantie terug voor MySQL.
 *
 * @return PDO
 */
function getPdo(): PDO
{
    static $pdo = null;

    if ($pdo instanceof PDO) {
        return $pdo;
    }

    global $DB_HOST, $DB_NAME, $DB_USER, $DB_PASS, $DB_CHARSET;

    $dsn = "mysql:host={$DB_HOST};dbname={$DB_NAME};charset={$DB_CHARSET}";
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];

    try {
        $pdo = new PDO($dsn, $DB_USER, $DB_PASS, $options);
    } catch (PDOException $e) {
        // In productie zou je dit loggen i.p.v. tonen
        http_response_code(500);
        echo '<h1>Database fout</h1>';
        echo '<p>Kan geen verbinding maken met de database. Controleer de configuratie.</p>';
        exit;
    }

    return $pdo;
}

/**
 * Haalt alle content blocks op als associatieve array: [id => ['title' => ..., 'body' => ...]]
 *
 * @return array<string, array<string, string|null>>
 */
function getContentBlocks(): array
{
    $pdo = getPdo();

    $stmt = $pdo->query('SELECT id, title, body FROM content_blocks');
    $rows = $stmt->fetchAll();

    $content = [];
    foreach ($rows as $row) {
        $content[$row['id']] = [
            'title' => $row['title'],
            'body'  => $row['body'],
        ];
    }

    return $content;
}

/**
 * Helper om een titel uit de content-blocks te halen met een fallback.
 */
function contentTitle(array $content, string $id, string $fallback): string
{
    if (isset($content[$id]['title']) && $content[$id]['title'] !== null && $content[$id]['title'] !== '') {
        return $content[$id]['title'];
    }
    return $fallback;
}

/**
 * Helper om een body uit de content-blocks te halen met een fallback.
 */
function contentBody(array $content, string $id, string $fallback): string
{
    if (isset($content[$id]['body']) && $content[$id]['body'] !== null && $content[$id]['body'] !== '') {
        return $content[$id]['body'];
    }
    return $fallback;
}

