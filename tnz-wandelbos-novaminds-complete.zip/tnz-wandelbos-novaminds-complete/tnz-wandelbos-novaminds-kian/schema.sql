-- SQL schema voor Geschiedenis Project contentblokken
-- Voer dit script uit in je MySQL/MariaDB-database

CREATE TABLE IF NOT EXISTS content_blocks (
    id VARCHAR(100) NOT NULL PRIMARY KEY,
    title VARCHAR(255) NULL,
    body TEXT NULL,
    updated_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Voorbeeldinhoud voor de homepage
INSERT INTO content_blocks (id, title, body) VALUES
  ('home_hero_title', 'Ontdek de Geschiedenis op een Interactieve Manier', 'Duik in het verleden met een meer interactieve leerervaring.'),
  ('home_hero_subtitle', NULL, 'Speel educatieve spellen en test je kennis met uitdagende quizzes over belangrijke historische gebeurtenissen.'),
  ('home_hero_cta_game', NULL, 'Speel het Spel'),
  ('home_hero_cta_quiz', NULL, 'Doe de Quiz'),

  ('home_origin_title', 'Hoe is dit project ontstaan?', NULL),
  ('home_origin_body', NULL,
   'Dit project is ontstaan uit de behoefte om geschiedenis toegankelijker en boeiender te maken voor een breed publiek. Traditionele lesmethoden kunnen soms droog en weinig inspirerend zijn.<br><br>'
   'Door interactieve elementen zoals spellen en quizzes te combineren met educatieve content, willen we een platform creëren waar leren leuk en uitdagend is. Ons team van docenten en ontwerpers heeft nauw samengewerkt om een ervaring te bouwen die zowel informatief als verrassend is.<br><br>'
   'Het project richt zich op belangrijke historische perioden en gebeurtenissen, samengevat op een manier die relevant is voor alle leeftijden. Het doel is om nieuwsgierigheid aan te wakkeren en mensen aan te moedigen om meer te leren over ons verleden.'
  ),

  ('home_why_title', 'Waarom dit project?', NULL),
  ('home_why_educatief_title', 'Educatief', NULL),
  ('home_why_educatief_body', NULL,
   'Leer op een gestructureerde manier over belangrijke historische gebeurtenissen. Elke activiteit is zorgvuldig samengesteld door experts.'
  ),
  ('home_why_interactief_title', 'Interactief', NULL),
  ('home_why_interactief_body', NULL,
   'Geen passief lezen meer. Doe mee met spellen, quizzes en interactieve opdrachten die je actief bij de stof betrekken.'
  ),
  ('home_why_alle_leeftijden_title', 'Voor alle leeftijden', NULL),
  ('home_why_alle_leeftijden_body', NULL,
   'Of je nu scholier bent, docent of gewoon geïnteresseerd in geschiedenis: dit platform biedt voor iedereen een leuke manier om kennis te maken met het verleden.'
  ),

  ('home_footer_title', 'Geschiedenis Project', NULL),
  ('home_footer_body', NULL,
   'Ontdek geschiedenis op een innovatieve en interactieve manier. Combineer spel, quiz en verdieping in één platform.'
  ),
  ('home_footer_contact', 'Contact', 'info@geschiedenisproject.nl'),
  ('home_footer_address', 'Adres', 'Amsterdam, Nederland'),
  ('home_footer_phone', 'Telefoon', '+31 (0)20 123 4567'),
  ('home_footer_follow', 'Volg ons', 'Facebook · Instagram · Twitter')
ON DUPLICATE KEY UPDATE
  title = VALUES(title),
  body  = VALUES(body);

