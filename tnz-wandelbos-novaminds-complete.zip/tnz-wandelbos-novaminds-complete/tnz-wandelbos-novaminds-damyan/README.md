# TNZ Wandelbos – Historische Wandelroute Philippine

Werkende PHP-webapp (zonder framework) voor een historische wandelroute met QR-locaties, locatie-informatie, afbeeldingen, quiz en mini-spel.

## Functionaliteiten

### Must (geïmplementeerd)

- **US1** QR-code doelpagina per locatie via `locatie.php?slug=...`
- **US6** Oude foto’s en afbeeldingen op locatiepagina
- **US7** Admin kan locatie-tekst toevoegen/bewerken
- **US10** Mobielvriendelijke interface

### Should (geïmplementeerd)

- **US5** Digitale kaart met locaties (Leaflet + OpenStreetMap)
- **US8** Admin kan afbeeldingen uploaden per locatie
- **US9** Historische stijl in bruin- en groentinten

### Could (deels geïmplementeerd)

- **US2** 360° panorama (optioneel via `panorama_url` per locatie)
- **US3** Quiz op locatiepagina (basis)
- **US4** Interactief memory-spel met niveaus (kind/jongere/volwassene)

## Projectstructuur

```text
.
├─ admin/
│  ├─ index.php
│  ├─ login.php
│  └─ logout.php
├─ assets/
│  ├─ css/style.css
│  └─ js/
│     ├─ location.js
│     └─ main.js
├─ config/config.php
├─ lib/
│  ├─ auth.php
│  ├─ db.php
│  └─ helpers.php
├─ data/                # SQLite database komt hier
├─ uploads/             # Geüploade afbeeldingen
├─ index.php
├─ locatie.php
├─ setup.php
└─ README.md
```

## Installatie (XAMPP)

1. Zet de map in je `htdocs` (staat al goed in jouw omgeving).
2. Zorg dat PHP met SQLite actief is in XAMPP.
3. Open in browser:

	- `http://localhost/Scalda/Wandelbos Repo/tnz-wandelbos-novaminds/setup.php`

4. Open daarna:

	- Publiek: `http://localhost/Scalda/Wandelbos Repo/tnz-wandelbos-novaminds/index.php`
	- Admin: `http://localhost/Scalda/Wandelbos Repo/tnz-wandelbos-novaminds/admin/login.php`

## Standaard admin login

- E-mail: `admin@wandelbos.local`
- Wachtwoord: `admin123!`

> Verander dit direct voor productiegebruik.

Je kunt deze waarden ook overschrijven via environment variables:

- `WANDELBOS_ADMIN_EMAIL`
- `WANDELBOS_ADMIN_PASSWORD`

## QR-code gebruik

Laat elke fysieke QR-code verwijzen naar een unieke locatie-URL, bijvoorbeeld:

- `http://localhost/Scalda/Wandelbos Repo/tnz-wandelbos-novaminds/locatie.php?slug=oude-dijkzone`

### QR-codes automatisch genereren en printen

- Open `http://localhost/Scalda/Wandelbos Repo/tnz-wandelbos-novaminds/admin/qrcodes.php`
- Deze pagina toont per locatie een QR-code en de bijbehorende URL
- Klik op **Print QR-codes** om het overzicht direct te printen
- Klik op **Sla op als lokale PNG's** om bestanden op te slaan in `uploads/qrcodes/`
- Klik op **Download alle als ZIP** om alle lokale QR-PNG’s in één keer te downloaden

## Opmerkingen

- Deze versie is een functionele MVP/demo met seed-data.
- Afbeeldingen worden lokaal opgeslagen in `uploads/`.

## Company-ready hardening (aanwezig)

- CSRF-beveiliging op admin formulieren (login, locatiebeheer, uploads, QR-acties)
- Security headers op publieke en admin pagina’s
- Veiliger sessie-cookie configuratie (`HttpOnly`, `SameSite`, `Secure` bij HTTPS)
- Striktere uploadvalidatie (type, extensie, grootte en image-check)
- Apache bescherming op gevoelige mappen:
	- `data/.htaccess` blokkeert directe toegang
	- `uploads/.htaccess` blokkeert uitvoerbare scripts

## Productie checklist

- Draai uitsluitend via HTTPS
- Stel sterke admin credentials in via environment variables
- Verwijder of bescherm `setup.php` na eerste installatie
- Maak periodieke back-ups van `data/wandelbos.sqlite` en `uploads/`