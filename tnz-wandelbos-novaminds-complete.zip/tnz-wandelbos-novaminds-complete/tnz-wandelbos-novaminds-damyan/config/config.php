<?php

declare(strict_types=1);

$isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');

if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'domain' => '',
        'secure' => $isHttps,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
}

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

define('BASE_PATH', __DIR__ . DIRECTORY_SEPARATOR . '..');
define('DB_PATH', BASE_PATH . DIRECTORY_SEPARATOR . 'data' . DIRECTORY_SEPARATOR . 'wandelbos.sqlite');
define('UPLOAD_DIR', BASE_PATH . DIRECTORY_SEPARATOR . 'uploads');
define('UPLOAD_PUBLIC_PATH', 'uploads');
define('APP_NAME', 'TNZ Wandelbos');
define('DEFAULT_ADMIN_EMAIL', getenv('WANDELBOS_ADMIN_EMAIL') ?: 'admin@wandelbos.local');
define('DEFAULT_ADMIN_PASSWORD', getenv('WANDELBOS_ADMIN_PASSWORD') ?: 'admin123!');
