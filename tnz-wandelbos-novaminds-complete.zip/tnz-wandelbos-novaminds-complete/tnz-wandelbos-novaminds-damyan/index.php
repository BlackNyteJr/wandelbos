<?php

declare(strict_types=1);

require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/lib/helpers.php';
require_once __DIR__ . '/lib/db.php';

apply_security_headers();
$locations = get_locations();
$firstLocationSlug = !empty($locations) ? (string) $locations[0]['slug'] : '';
?>
<!doctype html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Officiële website van TNZ Wandelbos: historische wandelroute in Philippine met QR-locaties, kaart en educatieve inhoud.">
    <meta name="theme-color" content="#2f5a46">
    <title><?= e(APP_NAME) ?> | Historische Route</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" crossorigin="" />
</head>
<body>
<header class="site-header">
    <div class="container nav-shell">
        <a class="logo" href="index.php" aria-label="TNZ Wandelbos home">
            <span class="logo-mark">WB</span>
            <span class="logo-text">TNZ Wandelbos</span>
        </a>
        <nav class="site-nav" aria-label="Hoofdnavigatie">
            <a class="is-active" href="index.php">Route</a>
            <a href="admin/login.php">Beheer</a>
        </nav>
    </div>
</header>

<main class="container page-flow">
    <section class="hero-panel">
        <div class="hero-content">
            <p class="eyebrow">Gemeenteproject Philippine</p>
            <h1>Historische wandelroute voor bewoners, bezoekers en scholen</h1>
            <p class="hero-lead">Verken het wandelbos via routepunten met QR-codes. Per locatie vind je betrouwbare historische context, foto’s en interactieve beleving.</p>
            <div class="hero-actions">
                <a class="btn btn-primary" href="#routekaart">Route bekijken</a>
                <?php if ($firstLocationSlug !== ''): ?>
                    <a class="btn btn-secondary" href="locatie.php?slug=<?= urlencode($firstLocationSlug) ?>">Start bij eerste locatie</a>
                <?php endif; ?>
            </div>
        </div>
        <div class="hero-stats" aria-label="Overzicht route">
            <article>
                <strong><?= count($locations) ?></strong>
                <span>Routepunten</span>
            </article>
            <article>
                <strong>100%</strong>
                <span>Mobiel geschikt</span>
            </article>
            <article>
                <strong>QR</strong>
                <span>Per locatie</span>
            </article>
        </div>
    </section>

    <section id="routekaart" class="surface-block">
        <div class="surface-head">
            <h2>Digitale routekaart</h2>
            <p>Bekijk alle locaties op kaart en open direct de juiste informatiepagina.</p>
        </div>
        <div id="map" class="map"></div>
    </section>

    <section class="surface-block steps-block">
        <div class="surface-head">
            <h2>Zo werkt het</h2>
            <p>Volg deze eenvoudige stappen voor een volledige routebeleving.</p>
        </div>
        <div class="steps-grid">
            <article>
                <strong>1</strong>
                <h3>Scan QR-code</h3>
                <p>Gebruik je smartphonecamera bij elk routepunt.</p>
            </article>
            <article>
                <strong>2</strong>
                <h3>Lees en bekijk</h3>
                <p>Bekijk historische uitleg, foto’s en contextinformatie.</p>
            </article>
            <article>
                <strong>3</strong>
                <h3>Interacteer</h3>
                <p>Doe quiz en spelonderdelen tijdens de wandeling.</p>
            </article>
        </div>
    </section>

    <section class="surface-block">
        <div class="surface-head">
            <h2>Routepunten</h2>
            <p>Elk punt bevat historische tekst, beeldmateriaal en interactieve onderdelen.</p>
        </div>
        <div class="card-grid">
            <?php foreach ($locations as $index => $location): ?>
                <article class="info-card">
                    <span class="chip">Stop <?= (int) $index + 1 ?></span>
                    <h4><?= e($location['name']) ?></h4>
                    <p><?= e($location['short_text']) ?></p>
                    <a class="link-arrow" href="locatie.php?slug=<?= urlencode((string) $location['slug']) ?>">Open locatie</a>
                </article>
            <?php endforeach; ?>
        </div>
    </section>
</main>

<footer class="site-footer">
    <div class="container footer-shell">
        <div>
            <p class="footer-title">TNZ Wandelbos</p>
            <p>Historische route Philippine</p>
        </div>
        <div>
            <p>© <?= date('Y') ?> Alle rechten voorbehouden</p>
            <p>In samenwerking met erfgoedpartners</p>
        </div>
    </div>
</footer>

<script>
    window.WANDELBOS_LOCATIONS = <?= json_encode(array_map(
        static fn($loc) => [
            'name' => $loc['name'],
            'slug' => $loc['slug'],
            'latitude' => $loc['latitude'],
            'longitude' => $loc['longitude'],
        ],
        $locations
    ), JSON_UNESCAPED_UNICODE) ?>;
</script>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js" crossorigin=""></script>
<script src="assets/js/main.js"></script>
</body>
</html>
