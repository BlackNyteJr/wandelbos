(function () {
    const checkButton = document.getElementById('check-quiz');
    const quizResult = document.getElementById('quiz-result');

    if (checkButton && quizResult) {
        checkButton.addEventListener('click', function () {
            const blocks = Array.from(document.querySelectorAll('.quiz-block'));
            if (blocks.length === 0) {
                return;
            }

            let score = 0;
            blocks.forEach((block) => {
                const selected = block.querySelector('input[type="radio"]:checked');
                const correct = block.dataset.correct;
                if (selected && selected.value === correct) {
                    score += 1;
                }
            });

            quizResult.textContent = `Je score: ${score} van ${blocks.length}`;
            quizResult.classList.add('is-visible');
        });
    }

    const board = document.getElementById('memory-board');
    const levelSelect = document.getElementById('level');
    const startButton = document.getElementById('start-game');
    const status = document.getElementById('memory-status');

    if (!board || !levelSelect || !startButton || !status) {
        return;
    }

    const allIcons = ['🌳', '🏰', '📜', '⛵', '🕰️', '🧭', '🏞️', '🧱'];
    let firstCard = null;
    let lock = false;
    let matches = 0;
    let neededMatches = 0;

    function shuffle(array) {
        for (let index = array.length - 1; index > 0; index -= 1) {
            const randomIndex = Math.floor(Math.random() * (index + 1));
            [array[index], array[randomIndex]] = [array[randomIndex], array[index]];
        }
        return array;
    }

    function createBoard() {
        const level = levelSelect.value;
        const pairCount = level === 'easy' ? 4 : level === 'hard' ? 8 : 6;
        const icons = allIcons.slice(0, pairCount);
        const deck = shuffle([...icons, ...icons]);

        board.innerHTML = '';
        firstCard = null;
        lock = false;
        matches = 0;
        neededMatches = pairCount;
        status.textContent = 'Zoek alle paren!';

        deck.forEach((icon) => {
            const card = document.createElement('button');
            card.type = 'button';
            card.className = 'memory-card';
            card.dataset.value = icon;
            card.dataset.revealed = '0';
            card.textContent = '?';

            card.addEventListener('click', function () {
                if (lock || card.classList.contains('matched') || card === firstCard) {
                    return;
                }

                reveal(card);

                if (!firstCard) {
                    firstCard = card;
                    return;
                }

                if (firstCard.dataset.value === card.dataset.value) {
                    firstCard.classList.add('matched');
                    card.classList.add('matched');
                    firstCard = null;
                    matches += 1;

                    if (matches === neededMatches) {
                        status.textContent = 'Klaar! Je hebt alle paren gevonden.';
                    }
                    return;
                }

                lock = true;
                const previousCard = firstCard;
                firstCard = null;

                setTimeout(function () {
                    hide(previousCard);
                    hide(card);
                    lock = false;
                }, 650);
            });

            board.appendChild(card);
        });
    }

    function reveal(card) {
        card.classList.add('revealed');
        card.dataset.revealed = '1';
        card.textContent = card.dataset.value;
    }

    function hide(card) {
        if (card.classList.contains('matched')) {
            return;
        }
        card.classList.remove('revealed');
        card.dataset.revealed = '0';
        card.textContent = '?';
    }

    startButton.addEventListener('click', createBoard);
    createBoard();
})();
