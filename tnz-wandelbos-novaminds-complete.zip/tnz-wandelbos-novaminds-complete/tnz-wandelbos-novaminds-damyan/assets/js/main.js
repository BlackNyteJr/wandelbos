(function () {
    const mapElement = document.getElementById('map');
    const points = window.WANDELBOS_LOCATIONS || [];

    if (!mapElement || typeof L === 'undefined' || points.length === 0) {
        return;
    }

    const valid = points.filter((point) => Number.isFinite(Number(point.latitude)) && Number.isFinite(Number(point.longitude)));

    if (valid.length === 0) {
        return;
    }

    const map = L.map('map').setView([valid[0].latitude, valid[0].longitude], 14);

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19,
        attribution: '&copy; OpenStreetMap'
    }).addTo(map);

    valid.forEach((location) => {
        const marker = L.marker([location.latitude, location.longitude]).addTo(map);
        marker.bindPopup(`<strong>${location.name}</strong><br><a href="locatie.php?slug=${encodeURIComponent(location.slug)}">Bekijk locatie</a>`);
    });
})();
