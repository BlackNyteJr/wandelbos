<?php

declare(strict_types=1);

require_once __DIR__ . '/db.php';

function is_admin_logged_in(): bool
{
    return !empty($_SESSION['admin_id']);
}

function require_admin_login(): void
{
    if (!is_admin_logged_in()) {
        set_flash('error', 'Log eerst in als administrator.');
        redirect('login.php');
    }
}

function login_admin(string $email, string $password): bool
{
    $pdo = db();
    $stmt = $pdo->prepare('SELECT * FROM admins WHERE email = :email LIMIT 1');
    $stmt->execute([':email' => $email]);
    $admin = $stmt->fetch();

    if (!$admin || !password_verify($password, $admin['password_hash'])) {
        return false;
    }

    $_SESSION['admin_id'] = (int) $admin['id'];
    $_SESSION['admin_email'] = $admin['email'];

    return true;
}

function logout_admin(): void
{
    unset($_SESSION['admin_id'], $_SESSION['admin_email']);
}
