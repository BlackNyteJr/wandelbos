<?php

declare(strict_types=1);

require_once __DIR__ . '/../config/config.php';

function db(): PDO
{
    static $pdo = null;

    if ($pdo instanceof PDO) {
        return $pdo;
    }

    if (!is_dir(dirname(DB_PATH))) {
        mkdir(dirname(DB_PATH), 0777, true);
    }

    $pdo = new PDO('sqlite:' . DB_PATH);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);

    initialize_database($pdo);

    return $pdo;
}

function initialize_database(PDO $pdo): void
{
    $pdo->exec(
        "CREATE TABLE IF NOT EXISTS admins (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );"
    );

    $pdo->exec(
        "CREATE TABLE IF NOT EXISTS locations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            slug TEXT UNIQUE NOT NULL,
            short_text TEXT,
            long_text TEXT,
            latitude REAL,
            longitude REAL,
            sort_order INTEGER DEFAULT 0,
            is_active INTEGER NOT NULL DEFAULT 1,
            panorama_url TEXT,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );"
    );

    $pdo->exec(
        "CREATE TABLE IF NOT EXISTS location_images (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            location_id INTEGER NOT NULL,
            image_url TEXT NOT NULL,
            caption TEXT,
            year_label TEXT,
            source TEXT,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(location_id) REFERENCES locations(id) ON DELETE CASCADE
        );"
    );

    $pdo->exec(
        "CREATE TABLE IF NOT EXISTS quizzes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            location_id INTEGER NOT NULL,
            question TEXT NOT NULL,
            option_a TEXT NOT NULL,
            option_b TEXT NOT NULL,
            option_c TEXT NOT NULL,
            correct_option TEXT NOT NULL,
            FOREIGN KEY(location_id) REFERENCES locations(id) ON DELETE CASCADE
        );"
    );

    seed_default_admin($pdo);
    seed_default_locations($pdo);
}

function seed_default_admin(PDO $pdo): void
{
    $count = (int) $pdo->query('SELECT COUNT(*) FROM admins')->fetchColumn();
    if ($count > 0) {
        return;
    }

    $stmt = $pdo->prepare('INSERT INTO admins (email, password_hash) VALUES (:email, :password_hash)');
    $stmt->execute([
        ':email' => DEFAULT_ADMIN_EMAIL,
        ':password_hash' => password_hash(DEFAULT_ADMIN_PASSWORD, PASSWORD_DEFAULT),
    ]);
}

function seed_default_locations(PDO $pdo): void
{
    $count = (int) $pdo->query('SELECT COUNT(*) FROM locations')->fetchColumn();
    if ($count > 0) {
        return;
    }

    $locations = [
        [
            'name' => 'Startpunt Philippine',
            'slug' => 'startpunt-philippine',
            'short_text' => 'Welkom bij de historische wandelroute van Philippine.',
            'long_text' => 'Op deze locatie begon vroeger de toegang naar het oude buitengebied. Hier start de route en vind je context over het ontstaan van de omgeving.',
            'latitude' => 51.2939,
            'longitude' => 3.7562,
            'sort_order' => 1,
            'panorama_url' => '',
        ],
        [
            'name' => 'Oude Dijkzone',
            'slug' => 'oude-dijkzone',
            'short_text' => 'Historische dijkstructuren beschermden de polders.',
            'long_text' => 'Deze zone laat zien hoe dijken de leefbaarheid van het gebied bepaalden. Je ziet nog sporen in de verkaveling en hoogteverschillen in het landschap.',
            'latitude' => 51.2951,
            'longitude' => 3.7543,
            'sort_order' => 2,
            'panorama_url' => '',
        ],
        [
            'name' => 'Voormalige Handelsroute',
            'slug' => 'voormalige-handelsroute',
            'short_text' => 'Handelsverkeer liep hier langs de route richting dorpskern.',
            'long_text' => 'Langs dit pad werden goederen vervoerd. Oude kaarten tonen dat deze route cruciaal was voor lokale handel en contact met omliggende gebieden.',
            'latitude' => 51.2960,
            'longitude' => 3.7584,
            'sort_order' => 3,
            'panorama_url' => '',
        ],
        [
            'name' => 'Bosrand Herinneringspunt',
            'slug' => 'bosrand-herinneringspunt',
            'short_text' => 'Een plek met verhalen van bewoners door de generaties heen.',
            'long_text' => 'Op dit punt worden verhalen over het dagelijks leven in het gebied gedeeld, ondersteund met oude foto’s en mondelinge geschiedenis.',
            'latitude' => 51.2927,
            'longitude' => 3.7598,
            'sort_order' => 4,
            'panorama_url' => '',
        ],
        [
            'name' => 'Eindpunt Wandelbos',
            'slug' => 'eindpunt-wandelbos',
            'short_text' => 'Afsluiting van de route met terugblik op de geschiedenis.',
            'long_text' => 'Hier sluit de route af. Bezoekers kunnen samenvatten wat ze hebben geleerd via quizvragen en een eenvoudig historisch memory-spel.',
            'latitude' => 51.2918,
            'longitude' => 3.7553,
            'sort_order' => 5,
            'panorama_url' => '',
        ],
    ];

    $stmt = $pdo->prepare(
        'INSERT INTO locations (name, slug, short_text, long_text, latitude, longitude, sort_order, panorama_url)
         VALUES (:name, :slug, :short_text, :long_text, :latitude, :longitude, :sort_order, :panorama_url)'
    );

    foreach ($locations as $location) {
        $stmt->execute([
            ':name' => $location['name'],
            ':slug' => $location['slug'],
            ':short_text' => $location['short_text'],
            ':long_text' => $location['long_text'],
            ':latitude' => $location['latitude'],
            ':longitude' => $location['longitude'],
            ':sort_order' => $location['sort_order'],
            ':panorama_url' => $location['panorama_url'],
        ]);
    }

    $locationIds = $pdo->query('SELECT id, slug FROM locations')->fetchAll();

    $imageStmt = $pdo->prepare(
        'INSERT INTO location_images (location_id, image_url, caption, year_label, source)
         VALUES (:location_id, :image_url, :caption, :year_label, :source)'
    );

    foreach ($locationIds as $location) {
        $imageStmt->execute([
            ':location_id' => $location['id'],
            ':image_url' => 'https://placehold.co/1200x700/5a4a2f/f1e7d0?text=Historische+foto',
            ':caption' => 'Voorbeeld historische foto van ' . $location['slug'],
            ':year_label' => 'ca. 1900',
            ':source' => 'Archief (demo)',
        ]);
    }

    $quizStmt = $pdo->prepare(
        'INSERT INTO quizzes (location_id, question, option_a, option_b, option_c, correct_option)
         VALUES (:location_id, :question, :option_a, :option_b, :option_c, :correct_option)'
    );

    foreach ($locationIds as $location) {
        $quizStmt->execute([
            ':location_id' => $location['id'],
            ':question' => 'Welke functie had deze plek historisch vooral?',
            ':option_a' => 'Handel en doorgang',
            ':option_b' => 'Luchthaven',
            ':option_c' => 'Industriehaven',
            ':correct_option' => 'a',
        ]);
    }
}

function get_locations(bool $activeOnly = true): array
{
    $pdo = db();
    $sql = 'SELECT * FROM locations';

    if ($activeOnly) {
        $sql .= ' WHERE is_active = 1';
    }

    $sql .= ' ORDER BY sort_order ASC, name ASC';

    return $pdo->query($sql)->fetchAll();
}

function get_location_by_slug(string $slug): ?array
{
    $pdo = db();
    $stmt = $pdo->prepare('SELECT * FROM locations WHERE slug = :slug LIMIT 1');
    $stmt->execute([':slug' => $slug]);

    $location = $stmt->fetch();

    return $location ?: null;
}

function get_location_by_id(int $id): ?array
{
    $pdo = db();
    $stmt = $pdo->prepare('SELECT * FROM locations WHERE id = :id LIMIT 1');
    $stmt->execute([':id' => $id]);

    $location = $stmt->fetch();

    return $location ?: null;
}

function get_images_for_location(int $locationId): array
{
    $pdo = db();
    $stmt = $pdo->prepare('SELECT * FROM location_images WHERE location_id = :location_id ORDER BY id DESC');
    $stmt->execute([':location_id' => $locationId]);

    return $stmt->fetchAll();
}

function get_quizzes_for_location(int $locationId): array
{
    $pdo = db();
    $stmt = $pdo->prepare('SELECT * FROM quizzes WHERE location_id = :location_id ORDER BY id ASC');
    $stmt->execute([':location_id' => $locationId]);

    return $stmt->fetchAll();
}
