<?php

declare(strict_types=1);

require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/lib/helpers.php';
require_once __DIR__ . '/lib/db.php';

apply_security_headers();

try {
    db();
    echo '<h1>Installatie voltooid</h1>';
    echo '<p>Database is aangemaakt/gecontroleerd.</p>';
    echo '<p>Admin login: <strong>' . htmlspecialchars(DEFAULT_ADMIN_EMAIL) . '</strong></p>';
    echo '<p>Admin wachtwoord: <strong>' . htmlspecialchars(DEFAULT_ADMIN_PASSWORD) . '</strong></p>';
    echo '<p><a href="index.php">Ga naar website</a> | <a href="admin/login.php">Ga naar admin</a></p>';
} catch (Throwable $e) {
    http_response_code(500);
    echo '<h1>Installatiefout</h1>';
    echo '<pre>' . htmlspecialchars($e->getMessage()) . '</pre>';
}
