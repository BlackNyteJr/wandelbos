<?php

declare(strict_types=1);

require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/lib/helpers.php';
require_once __DIR__ . '/lib/db.php';

apply_security_headers();
$slug = (string) ($_GET['slug'] ?? '');
$location = $slug !== '' ? get_location_by_slug($slug) : null;

if (!$location) {
    http_response_code(404);
}

$images = $location ? get_images_for_location((int) $location['id']) : [];
$quizzes = $location ? get_quizzes_for_location((int) $location['id']) : [];
?>
<!doctype html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Historische locatiepagina van de TNZ Wandelbos-route in Philippine.">
    <title><?= $location ? e($location['name']) : 'Locatie niet gevonden' ?> | TNZ Wandelbos</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<header class="site-header">
    <div class="container nav-shell">
        <a class="logo" href="index.php" aria-label="TNZ Wandelbos home">
            <span class="logo-mark">WB</span>
            <span class="logo-text">TNZ Wandelbos</span>
        </a>
        <nav class="site-nav" aria-label="Hoofdnavigatie">
            <a class="is-active" href="index.php">Route</a>
            <a href="admin/login.php">Beheer</a>
        </nav>
    </div>
</header>

<main class="container page-flow">
    <?php if (!$location): ?>
        <section class="surface-block">
            <h2>Locatie niet gevonden</h2>
            <p>De QR-link is ongeldig of verlopen.</p>
            <a class="btn btn-primary" href="index.php">Ga naar route-overzicht</a>
        </section>
    <?php else: ?>
        <section class="hero-panel compact">
            <div class="hero-content">
                <p class="eyebrow">Locatie-informatie</p>
                <h1><?= e($location['name']) ?></h1>
                <p class="hero-lead"><?= e($location['short_text']) ?></p>
                <p><?= nl2br(e($location['long_text'])) ?></p>
                <div class="hero-actions">
                    <a class="btn btn-secondary" href="index.php">Terug naar routekaart</a>
                </div>
            </div>
        </section>

        <section class="surface-block">
            <div class="surface-head">
                <h2>Historisch beeldmateriaal</h2>
                <p>Bekijk beschikbare foto’s en illustraties van deze locatie.</p>
            </div>
            <?php if (!$images): ?>
                <p>Er is momenteel nog geen beeldmateriaal beschikbaar voor dit punt.</p>
            <?php else: ?>
                <div class="gallery-grid">
                    <?php foreach ($images as $image): ?>
                        <figure class="media-card">
                            <a href="<?= e($image['image_url']) ?>" target="_blank" rel="noopener noreferrer">
                                <img src="<?= e($image['image_url']) ?>" alt="<?= e($image['caption'] ?: 'Historische afbeelding') ?>">
                            </a>
                            <figcaption>
                                <strong><?= e($image['caption'] ?: 'Zonder bijschrift') ?></strong>
                                <?php if (!empty($image['year_label'])): ?>
                                    <span><?= e($image['year_label']) ?></span>
                                <?php endif; ?>
                            </figcaption>
                        </figure>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </section>

        <?php if (!empty($location['panorama_url'])): ?>
            <section class="surface-block">
                <div class="surface-head">
                    <h2>360° Panorama</h2>
                    <p>Bekijk deze locatie in een panoramische weergave.</p>
                </div>
                <iframe class="panorama" src="<?= e($location['panorama_url']) ?>" title="360 graden panorama"></iframe>
            </section>
        <?php endif; ?>

        <?php if ($quizzes): ?>
            <section class="surface-block">
                <div class="surface-head">
                    <h2>Kennistoets</h2>
                    <p>Test je kennis over dit historische routepunt.</p>
                </div>
                <form id="quiz-form" class="stack quiz-form">
                    <?php foreach ($quizzes as $index => $quiz): ?>
                        <fieldset class="quiz-block" data-correct="<?= e($quiz['correct_option']) ?>">
                            <legend class="quiz-question"><?= ($index + 1) . '. ' . e($quiz['question']) ?></legend>

                            <label class="quiz-option">
                                <input type="radio" name="q<?= (int) $quiz['id'] ?>" value="a">
                                <span><?= e($quiz['option_a']) ?></span>
                            </label>
                            <label class="quiz-option">
                                <input type="radio" name="q<?= (int) $quiz['id'] ?>" value="b">
                                <span><?= e($quiz['option_b']) ?></span>
                            </label>
                            <label class="quiz-option">
                                <input type="radio" name="q<?= (int) $quiz['id'] ?>" value="c">
                                <span><?= e($quiz['option_c']) ?></span>
                            </label>
                        </fieldset>
                    <?php endforeach; ?>

                    <div class="quiz-actions">
                        <button type="button" id="check-quiz" class="btn btn-primary">Controleer antwoorden</button>
                        <p id="quiz-result" class="quiz-result" aria-live="polite"></p>
                    </div>
                </form>
            </section>
        <?php endif; ?>

        <section class="surface-block">
            <div class="surface-head">
                <h2>Interactief memory-spel</h2>
                <p>Kies een niveau en voltooi het spel tijdens je wandeling.</p>
            </div>
            <div class="game-toolbar">
                <label for="level">Niveau:</label>
                <select id="level">
                    <option value="easy">Kind (4 paren)</option>
                    <option value="medium" selected>Jongere (6 paren)</option>
                    <option value="hard">Volwassene (8 paren)</option>
                </select>
                <button type="button" id="start-game" class="btn btn-secondary">Start spel</button>
            </div>
            <div id="memory-board" class="memory-board"></div>
            <p id="memory-status"></p>
        </section>
    <?php endif; ?>
</main>

<footer class="site-footer">
    <div class="container footer-shell">
        <div>
            <p class="footer-title">TNZ Wandelbos</p>
            <p>Historische route Philippine</p>
        </div>
        <div>
            <p>© <?= date('Y') ?> Alle rechten voorbehouden</p>
            <p><a href="index.php">Terug naar routeoverzicht</a></p>
        </div>
    </div>
</footer>

<script src="assets/js/location.js"></script>
</body>
</html>
