<?php

declare(strict_types=1);

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../lib/helpers.php';
require_once __DIR__ . '/../lib/db.php';
require_once __DIR__ . '/../lib/auth.php';

apply_security_headers();
require_admin_login();

$scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$host = $_SERVER['HTTP_HOST'] ?? 'localhost';
$basePath = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/admin')), '/');
$projectPath = preg_replace('#/admin$#', '', $basePath) ?: '';

$localQrDir = UPLOAD_DIR . DIRECTORY_SEPARATOR . 'qrcodes';
$localQrPublicBase = '../' . UPLOAD_PUBLIC_PATH . '/qrcodes';

function location_url(string $scheme, string $host, string $projectPath, string $slug): string
{
    return sprintf(
        '%s://%s%s/locatie.php?slug=%s',
        $scheme,
        $host,
        $projectPath,
        urlencode($slug)
    );
}

function qr_image_url(string $targetUrl): string
{
    return 'https://quickchart.io/qr?size=300&text=' . rawurlencode($targetUrl);
}

function qr_file_name(string $slug): string
{
    $normalized = preg_replace('/[^a-z0-9\-]+/i', '-', $slug) ?: 'locatie';
    return trim(strtolower($normalized), '-') . '.png';
}

function fetch_qr_binary(string $targetUrl): ?string
{
    $context = stream_context_create([
        'http' => [
            'method' => 'GET',
            'timeout' => 12,
            'ignore_errors' => true,
        ],
    ]);

    $binary = @file_get_contents(qr_image_url($targetUrl), false, $context);

    return $binary !== false ? $binary : null;
}

function create_qr_zip(string $directoryPath, string $zipPath): bool
{
    if (!class_exists('ZipArchive')) {
        return false;
    }

    $files = glob($directoryPath . DIRECTORY_SEPARATOR . '*.png') ?: [];
    if (count($files) === 0) {
        return false;
    }

    $zip = new ZipArchive();
    if ($zip->open($zipPath, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
        return false;
    }

    foreach ($files as $file) {
        $zip->addFile($file, basename($file));
    }

    $zip->close();

    return is_file($zipPath);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && (string) ($_POST['action'] ?? '') === 'save_local_qr') {
    verify_csrf_or_fail();

    if (!is_dir($localQrDir)) {
        mkdir($localQrDir, 0777, true);
    }

    $locationsForSave = get_locations(false);
    $saved = 0;
    $failed = 0;

    foreach ($locationsForSave as $location) {
        $slug = (string) $location['slug'];
        $targetUrl = location_url($scheme, $host, $projectPath, $slug);
        $qrBinary = fetch_qr_binary($targetUrl);

        if ($qrBinary === null) {
            $failed++;
            continue;
        }

        $filePath = $localQrDir . DIRECTORY_SEPARATOR . qr_file_name($slug);
        $written = @file_put_contents($filePath, $qrBinary);

        if ($written === false) {
            $failed++;
            continue;
        }

        $saved++;
    }

    if ($failed === 0) {
        set_flash('success', "Lokale QR-bestanden opgeslagen ({$saved}).");
    } else {
        set_flash('error', "{$saved} opgeslagen, {$failed} mislukt. Controleer internetverbinding/schrijfrechten.");
    }

    redirect('qrcodes.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && (string) ($_POST['action'] ?? '') === 'download_zip_qr') {
    verify_csrf_or_fail();

    if (!is_dir($localQrDir)) {
        set_flash('error', 'Geen lokale QR-map gevonden. Sla eerst PNG\'s op.');
        redirect('qrcodes.php');
    }

    $zipFileName = 'wandelbos-qrcodes-' . date('Ymd-His') . '.zip';
    $zipPath = sys_get_temp_dir() . DIRECTORY_SEPARATOR . $zipFileName;

    if (!create_qr_zip($localQrDir, $zipPath)) {
        set_flash('error', 'ZIP maken is mislukt. Controleer of ZIP-extensie actief is en er PNG\'s bestaan.');
        redirect('qrcodes.php');
    }

    header('Content-Type: application/zip');
    header('Content-Disposition: attachment; filename="' . $zipFileName . '"');
    header('Content-Length: ' . (string) filesize($zipPath));
    readfile($zipPath);
    @unlink($zipPath);
    exit;
}

$locations = get_locations(false);
$flash = get_flash();
?>
<!doctype html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QR-codes | TNZ Wandelbos</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<header class="site-header">
    <div class="container nav-shell">
        <a class="logo" href="../index.php" aria-label="TNZ Wandelbos home">
            <span class="logo-mark">WB</span>
            <span class="logo-text">TNZ Wandelbos Admin</span>
        </a>
        <nav class="site-nav" aria-label="Admin navigatie">
            <a href="index.php">Dashboard</a>
            <a class="is-active" href="qrcodes.php">QR-codes</a>
            <a href="../index.php">Publieke site</a>
        </nav>
    </div>
</header>

<main class="container page-flow qr-page">
    <section class="hero-panel compact">
        <div class="hero-content">
            <p class="eyebrow">QR-beheer</p>
            <h1>QR-codes per routepunt</h1>
            <p class="hero-lead">Print, sla lokaal op of download alle QR-codes als ZIP voor plaatsing langs de route.</p>
        </div>
        <div class="hero-stats">
            <article>
                <strong><?= count($locations) ?></strong>
                <span>Beschikbare codes</span>
            </article>
            <article>
                <strong>PNG</strong>
                <span>Lokale export</span>
            </article>
            <article>
                <strong>ZIP</strong>
                <span>Bulk download</span>
            </article>
        </div>
    </section>

    <?php if ($flash): ?>
        <p class="flash <?= e($flash['type']) ?>"><?= e($flash['message']) ?></p>
    <?php endif; ?>

    <section class="surface-block actions no-print">
        <h2>Printoverzicht</h2>
        <p class="surface-sub">Gebruik deze pagina om QR-codes uit te printen en op routepunten te plaatsen.</p>
        <div class="actions-wrap">
            <button class="btn btn-primary" type="button" onclick="window.print()">Print QR-codes</button>
            <form method="post" style="margin:0;">
                <input type="hidden" name="action" value="save_local_qr">
                <?= csrf_input() ?>
                <button class="btn btn-secondary" type="submit">Sla op als lokale PNG's</button>
            </form>
            <form method="post" style="margin:0;">
                <input type="hidden" name="action" value="download_zip_qr">
                <?= csrf_input() ?>
                <button class="btn btn-primary" type="submit">Download alle als ZIP</button>
            </form>
        </div>
    </section>

    <section class="card-grid qr-grid">
        <?php foreach ($locations as $location): ?>
            <?php $targetUrl = location_url($scheme, $host, $projectPath, (string) $location['slug']); ?>
            <?php $localQrFile = $localQrPublicBase . '/' . qr_file_name((string) $location['slug']); ?>
            <?php $localQrPath = $localQrDir . DIRECTORY_SEPARATOR . qr_file_name((string) $location['slug']); ?>
            <article class="info-card qr-card">
                <h3><?= e($location['name']) ?></h3>
                <img src="<?= e(qr_image_url($targetUrl)) ?>" alt="QR-code voor <?= e($location['name']) ?>">
                <p class="qr-url"><a href="<?= e($targetUrl) ?>" target="_blank" rel="noopener noreferrer"><?= e($targetUrl) ?></a></p>
                <?php if (is_file($localQrPath)): ?>
                    <p><a class="link-arrow" href="<?= e($localQrFile) ?>" download>Download lokale PNG</a></p>
                <?php endif; ?>
            </article>
        <?php endforeach; ?>
    </section>
</main>

<footer class="site-footer">
    <div class="container footer-shell">
        <div>
            <p class="footer-title">TNZ Wandelbos Admin</p>
            <p>QR-materialen voor publicatie</p>
        </div>
        <div>
            <p>© <?= date('Y') ?> Alle rechten voorbehouden</p>
        </div>
    </div>
</footer>
</body>
</html>