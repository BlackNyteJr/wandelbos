<?php

declare(strict_types=1);

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../lib/helpers.php';
require_once __DIR__ . '/../lib/auth.php';

apply_security_headers();
logout_admin();
set_flash('success', 'Je bent uitgelogd.');
redirect('login.php');
