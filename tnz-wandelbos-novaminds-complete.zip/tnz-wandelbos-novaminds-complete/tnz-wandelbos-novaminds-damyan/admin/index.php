<?php

declare(strict_types=1);

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../lib/helpers.php';
require_once __DIR__ . '/../lib/db.php';
require_once __DIR__ . '/../lib/auth.php';

apply_security_headers();
require_admin_login();

$pdo = db();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf_or_fail();

    $action = (string) ($_POST['action'] ?? '');

    if ($action === 'save_location') {
        $id = (int) ($_POST['id'] ?? 0);
        $name = trim((string) ($_POST['name'] ?? ''));
        $slug = trim((string) ($_POST['slug'] ?? ''));
        $shortText = trim((string) ($_POST['short_text'] ?? ''));
        $longText = trim((string) ($_POST['long_text'] ?? ''));
        $latitude = $_POST['latitude'] !== '' ? (float) $_POST['latitude'] : null;
        $longitude = $_POST['longitude'] !== '' ? (float) $_POST['longitude'] : null;
        $sortOrder = (int) ($_POST['sort_order'] ?? 0);
        $isActive = isset($_POST['is_active']) ? 1 : 0;
        $panoramaUrl = trim((string) ($_POST['panorama_url'] ?? ''));

        if ($name === '' || $slug === '') {
            set_flash('error', 'Naam en slug zijn verplicht.');
            redirect('index.php');
        }

        if (!preg_match('/^[a-z0-9\-]+$/', $slug)) {
            set_flash('error', 'Slug mag alleen kleine letters, cijfers en streepjes bevatten.');
            redirect('index.php');
        }

        if ($id > 0) {
            $stmt = $pdo->prepare(
                'UPDATE locations
                 SET name = :name, slug = :slug, short_text = :short_text, long_text = :long_text,
                     latitude = :latitude, longitude = :longitude, sort_order = :sort_order,
                     is_active = :is_active, panorama_url = :panorama_url, updated_at = CURRENT_TIMESTAMP
                 WHERE id = :id'
            );
            $stmt->execute([
                ':name' => $name,
                ':slug' => $slug,
                ':short_text' => $shortText,
                ':long_text' => $longText,
                ':latitude' => $latitude,
                ':longitude' => $longitude,
                ':sort_order' => $sortOrder,
                ':is_active' => $isActive,
                ':panorama_url' => $panoramaUrl,
                ':id' => $id,
            ]);
            set_flash('success', 'Locatie bijgewerkt.');
        } else {
            $stmt = $pdo->prepare(
                'INSERT INTO locations (name, slug, short_text, long_text, latitude, longitude, sort_order, is_active, panorama_url)
                 VALUES (:name, :slug, :short_text, :long_text, :latitude, :longitude, :sort_order, :is_active, :panorama_url)'
            );
            $stmt->execute([
                ':name' => $name,
                ':slug' => $slug,
                ':short_text' => $shortText,
                ':long_text' => $longText,
                ':latitude' => $latitude,
                ':longitude' => $longitude,
                ':sort_order' => $sortOrder,
                ':is_active' => $isActive,
                ':panorama_url' => $panoramaUrl,
            ]);
            set_flash('success', 'Locatie toegevoegd.');
        }

        redirect('index.php');
    }

    if ($action === 'upload_image') {
        $locationId = (int) ($_POST['location_id'] ?? 0);
        $caption = trim((string) ($_POST['caption'] ?? ''));
        $yearLabel = trim((string) ($_POST['year_label'] ?? ''));
        $source = trim((string) ($_POST['source'] ?? ''));

        if ($locationId <= 0 || empty($_FILES['image']['name'])) {
            set_flash('error', 'Kies een locatie en afbeelding.');
            redirect('index.php');
        }

        if (!is_dir(UPLOAD_DIR)) {
            mkdir(UPLOAD_DIR, 0777, true);
        }

        $allowedMimeTypes = ['image/jpeg', 'image/png', 'image/webp'];
        $allowedExtensions = ['jpg', 'jpeg', 'png', 'webp'];
        $maxFileSize = 5 * 1024 * 1024;
        $tmpName = $_FILES['image']['tmp_name'] ?? '';
        $mimeType = $tmpName !== '' ? (mime_content_type($tmpName) ?: '') : '';
        $fileSize = (int) ($_FILES['image']['size'] ?? 0);
        $originalName = (string) ($_FILES['image']['name'] ?? '');
        $extension = strtolower((string) pathinfo($originalName, PATHINFO_EXTENSION));

        if (!is_uploaded_file($tmpName)) {
            set_flash('error', 'Ongeldige uploadaanvraag.');
            redirect('index.php');
        }

        if ($fileSize <= 0 || $fileSize > $maxFileSize) {
            set_flash('error', 'Bestand te groot of ongeldig. Maximum is 5MB.');
            redirect('index.php');
        }

        if (!in_array($extension, $allowedExtensions, true)) {
            set_flash('error', 'Bestandsextensie niet toegestaan.');
            redirect('index.php');
        }

        if (!in_array($mimeType, $allowedMimeTypes, true)) {
            set_flash('error', 'Alleen JPG, PNG en WEBP zijn toegestaan.');
            redirect('index.php');
        }

        if (@getimagesize($tmpName) === false) {
            set_flash('error', 'Geüpload bestand is geen geldige afbeelding.');
            redirect('index.php');
        }

        $fileName = uniqid('img_', true) . '.' . strtolower($extension);
        $targetPath = UPLOAD_DIR . DIRECTORY_SEPARATOR . $fileName;

        if (!move_uploaded_file($tmpName, $targetPath)) {
            set_flash('error', 'Upload mislukt.');
            redirect('index.php');
        }

        $publicPath = UPLOAD_PUBLIC_PATH . '/' . $fileName;

        $stmt = $pdo->prepare(
            'INSERT INTO location_images (location_id, image_url, caption, year_label, source)
             VALUES (:location_id, :image_url, :caption, :year_label, :source)'
        );
        $stmt->execute([
            ':location_id' => $locationId,
            ':image_url' => $publicPath,
            ':caption' => $caption,
            ':year_label' => $yearLabel,
            ':source' => $source,
        ]);

        set_flash('success', 'Afbeelding geüpload.');
        redirect('index.php');
    }
}

$locations = get_locations(false);
$flash = get_flash();
$editId = (int) ($_GET['edit'] ?? 0);
$editLocation = $editId > 0 ? get_location_by_id($editId) : null;
?>
<!doctype html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin dashboard | TNZ Wandelbos</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<header class="site-header">
    <div class="container nav-shell">
        <a class="logo" href="../index.php" aria-label="TNZ Wandelbos home">
            <span class="logo-mark">WB</span>
            <span class="logo-text">TNZ Wandelbos Admin</span>
        </a>
        <nav class="site-nav" aria-label="Admin navigatie">
            <a class="is-active" href="index.php">Dashboard</a>
            <a href="qrcodes.php">QR-codes</a>
            <a href="../index.php">Publieke site</a>
            <a href="logout.php">Uitloggen</a>
        </nav>
    </div>
</header>

<main class="container page-flow">
    <section class="hero-panel compact">
        <div class="hero-content">
            <p class="eyebrow">Beheercentrum</p>
            <h1>Inhoud en routepunten beheren</h1>
            <p class="hero-lead">Werk locatiegegevens bij, voeg beeldmateriaal toe en beheer publicatiemateriaal vanuit één dashboard.</p>
        </div>
        <div class="hero-stats">
            <article>
                <strong><?= count($locations) ?></strong>
                <span>Locaties</span>
            </article>
            <article>
                <strong>Media</strong>
                <span>Uploadbeheer</span>
            </article>
            <article>
                <strong>QR</strong>
                <span>Exportopties</span>
            </article>
        </div>
    </section>

    <?php if ($flash): ?>
        <p class="flash <?= e($flash['type']) ?>"><?= e($flash['message']) ?></p>
    <?php endif; ?>

    <section class="surface-block">
        <h2><?= $editLocation ? 'Locatie bewerken' : 'Nieuwe locatie toevoegen' ?></h2>
        <p class="surface-sub">Vul de basisgegevens van een routepunt in. Wijzigingen zijn direct zichtbaar op de website.</p>
        <form method="post" class="stack">
            <input type="hidden" name="action" value="save_location">
            <input type="hidden" name="id" value="<?= (int) ($editLocation['id'] ?? 0) ?>">
            <?= csrf_input() ?>

            <label>Naam
                <input type="text" name="name" required value="<?= e($editLocation['name'] ?? '') ?>">
            </label>

            <label>Slug
                <input type="text" name="slug" required value="<?= e($editLocation['slug'] ?? '') ?>" placeholder="bijv. oude-dijkzone">
            </label>

            <label>Korte tekst
                <textarea name="short_text" rows="2"><?= e($editLocation['short_text'] ?? '') ?></textarea>
            </label>

            <label>Lange tekst
                <textarea name="long_text" rows="5"><?= e($editLocation['long_text'] ?? '') ?></textarea>
            </label>

            <div class="form-row">
                <label>Latitude
                    <input type="number" step="0.000001" name="latitude" value="<?= e(isset($editLocation['latitude']) ? (string)$editLocation['latitude'] : '') ?>">
                </label>
                <label>Longitude
                    <input type="number" step="0.000001" name="longitude" value="<?= e(isset($editLocation['longitude']) ? (string)$editLocation['longitude'] : '') ?>">
                </label>
            </div>

            <div class="form-row">
                <label>Volgorde
                    <input type="number" name="sort_order" value="<?= e(isset($editLocation['sort_order']) ? (string)$editLocation['sort_order'] : '0') ?>">
                </label>
                <label>Panorama URL (optioneel)
                    <input type="url" name="panorama_url" value="<?= e($editLocation['panorama_url'] ?? '') ?>">
                </label>
            </div>

            <label class="checkbox">
                <input type="checkbox" name="is_active" <?= (!isset($editLocation['is_active']) || (int)$editLocation['is_active'] === 1) ? 'checked' : '' ?>>
                Actief tonen op website
            </label>

            <button class="btn btn-primary" type="submit">Opslaan</button>
        </form>
    </section>

    <section class="surface-block">
        <h2>Afbeelding uploaden</h2>
        <p class="surface-sub">Upload historische foto’s en voeg context toe met jaartal en bronvermelding.</p>
        <form method="post" enctype="multipart/form-data" class="stack">
            <input type="hidden" name="action" value="upload_image">
            <?= csrf_input() ?>

            <label>Locatie
                <select name="location_id" required>
                    <option value="">Kies locatie</option>
                    <?php foreach ($locations as $location): ?>
                        <option value="<?= (int) $location['id'] ?>"><?= e($location['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </label>

            <label>Afbeelding (JPG/PNG/WEBP)
                <input type="file" name="image" accept="image/jpeg,image/png,image/webp" required>
            </label>

            <label>Bijschrift
                <input type="text" name="caption">
            </label>

            <div class="form-row">
                <label>Jaartal
                    <input type="text" name="year_label" placeholder="bijv. ca. 1900">
                </label>
                <label>Bron
                    <input type="text" name="source" placeholder="bijv. Gemeentearchief">
                </label>
            </div>

            <button class="btn btn-primary" type="submit">Uploaden</button>
        </form>
    </section>

    <section class="surface-block">
        <h2>Bestaande locaties</h2>
        <p class="surface-sub">Overzicht van alle routepunten met directe links voor bewerken en QR-doeleinden.</p>
        <div class="card-grid">
            <?php foreach ($locations as $location): ?>
                <article class="info-card admin-item">
                    <h3><?= e($location['name']) ?></h3>
                    <p><?= e($location['short_text']) ?></p>
                    <p class="admin-url"><strong>QR-URL:</strong> <a href="../locatie.php?slug=<?= urlencode((string) $location['slug']) ?>" target="_blank" rel="noopener noreferrer">locatie.php?slug=<?= e($location['slug']) ?></a></p>
                    <div class="admin-location-actions">
                        <a class="btn btn-secondary" href="index.php?edit=<?= (int) $location['id'] ?>">Bewerk</a>
                        <a class="btn btn-primary" href="../locatie.php?slug=<?= urlencode((string) $location['slug']) ?>" target="_blank" rel="noopener noreferrer">Open</a>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
    </section>
</main>

<footer class="site-footer">
    <div class="container footer-shell">
        <div>
            <p class="footer-title">TNZ Wandelbos Admin</p>
            <p>Beheeromgeving voor routecontent</p>
        </div>
        <div>
            <p>© <?= date('Y') ?> Alle rechten voorbehouden</p>
        </div>
    </div>
</footer>
</body>
</html>
