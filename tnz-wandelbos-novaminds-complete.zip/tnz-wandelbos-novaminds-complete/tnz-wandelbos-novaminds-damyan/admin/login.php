<?php

declare(strict_types=1);

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../lib/helpers.php';
require_once __DIR__ . '/../lib/auth.php';

apply_security_headers();

if (is_admin_logged_in()) {
    redirect('index.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf_or_fail();

    $email = trim((string) ($_POST['email'] ?? ''));
    $password = (string) ($_POST['password'] ?? '');

    if (login_admin($email, $password)) {
        set_flash('success', 'Succesvol ingelogd.');
        redirect('index.php');
    }

    set_flash('error', 'Ongeldige inloggegevens.');
    redirect('login.php');
}

$flash = get_flash();
?>
<!doctype html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin login | TNZ Wandelbos</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<header class="site-header">
    <div class="container nav-shell">
        <a class="logo" href="../index.php" aria-label="TNZ Wandelbos home">
            <span class="logo-mark">WB</span>
            <span class="logo-text">TNZ Wandelbos</span>
        </a>
        <nav class="site-nav" aria-label="Hoofdnavigatie">
            <a href="../index.php">Publieke site</a>
        </nav>
    </div>
</header>

<main class="container page-flow auth-page">
    <section class="surface-block auth-card">
        <p class="eyebrow">Beheeromgeving</p>
        <h1>Veilige administrator login</h1>
        <p>Log in om routecontent, locaties en QR-materiaal centraal te beheren.</p>

        <?php if ($flash): ?>
            <p class="flash <?= e($flash['type']) ?>"><?= e($flash['message']) ?></p>
        <?php endif; ?>

        <form method="post" class="stack">
            <?= csrf_input() ?>
            <label for="email">E-mailadres</label>
            <input type="email" id="email" name="email" required>

            <label for="password">Wachtwoord</label>
            <input type="password" id="password" name="password" required>

            <button class="btn btn-primary" type="submit">Inloggen</button>
        </form>

        <p><a href="../index.php">Terug naar publieke website</a></p>
    </section>
</main>

<footer class="site-footer">
    <div class="container footer-shell">
        <div>
            <p class="footer-title">TNZ Wandelbos Admin</p>
            <p>Beheeromgeving</p>
        </div>
        <div>
            <p>© <?= date('Y') ?> Alle rechten voorbehouden</p>
        </div>
    </div>
</footer>
</body>
</html>
